import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  useColorScheme,
  Alert,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { CreditCard, Euro, Shield } from 'lucide-react-native';

interface StripePaymentFormProps {
  amount: number;
  description: string;
  onPaymentSuccess: (paymentIntentId: string) => void;
  onPaymentError: (error: string) => void;
  customerEmail?: string;
}

export function StripePaymentForm({ 
  amount, 
  description, 
  onPaymentSuccess, 
  onPaymentError,
  customerEmail 
}: StripePaymentFormProps) {
  const colorScheme = useColorScheme();
  const [isLoading, setIsLoading] = useState(false);

  const colors = {
    light: {
      primary: '#2563EB',
      success: '#10B981',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      success: '#34D399',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  const createPaymentIntent = async () => {
    try {
      const response = await fetch('/payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: amount * 100, // Convert to cents
          currency: 'eur',
          description,
          customer_email: customerEmail,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erreur lors de la création du paiement');
      }

      return data;
    } catch (error) {
      throw error;
    }
  };

  const handleWebPayment = async () => {
    try {
      const { clientSecret, paymentIntentId } = await createPaymentIntent();

      // Pour le web, on simule le processus Stripe
      // Dans une vraie app, vous utiliseriez Stripe.js
      Alert.alert(
        'Paiement Stripe',
        `Redirection vers Stripe Checkout pour ${amount}€`,
        [
          {
            text: 'Simuler succès',
            onPress: () => onPaymentSuccess(paymentIntentId),
          },
          {
            text: 'Simuler échec',
            style: 'destructive',
            onPress: () => onPaymentError('Paiement annulé par l\'utilisateur'),
          },
        ]
      );
    } catch (error) {
      onPaymentError(error instanceof Error ? error.message : 'Erreur de paiement');
    }
  };

  const handleNativePayment = async () => {
    try {
      // Pour les plateformes natives, vous utiliseriez @stripe/stripe-react-native
      // Ici on simule le processus
      const { clientSecret, paymentIntentId } = await createPaymentIntent();

      Alert.alert(
        'Paiement Stripe',
        `Ouverture de Stripe Payment Sheet pour ${amount}€`,
        [
          {
            text: 'Simuler succès',
            onPress: () => onPaymentSuccess(paymentIntentId),
          },
          {
            text: 'Simuler échec',
            style: 'destructive',
            onPress: () => onPaymentError('Paiement annulé par l\'utilisateur'),
          },
        ]
      );
    } catch (error) {
      onPaymentError(error instanceof Error ? error.message : 'Erreur de paiement');
    }
  };

  const handlePayment = async () => {
    setIsLoading(true);
    try {
      if (Platform.OS === 'web') {
        await handleWebPayment();
      } else {
        await handleNativePayment();
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
      <View style={styles.header}>
        <View style={[styles.iconContainer, { backgroundColor: currentColors.primary + '20' }]}>
          <Euro size={24} color={currentColors.primary} />
        </View>
        <View style={styles.paymentInfo}>
          <Text style={[styles.amount, { color: currentColors.text }]}>
            {amount.toFixed(2)} €
          </Text>
          <Text style={[styles.description, { color: currentColors.textSecondary }]}>
            {description}
          </Text>
        </View>
      </View>

      <View style={[styles.securityInfo, { backgroundColor: currentColors.success + '10', borderColor: currentColors.success }]}>
        <Shield size={16} color={currentColors.success} />
        <Text style={[styles.securityText, { color: currentColors.success }]}>
          Paiement sécurisé par Stripe
        </Text>
      </View>

      <TouchableOpacity
        style={[styles.payButton, { backgroundColor: currentColors.primary }]}
        onPress={handlePayment}
        disabled={isLoading}
      >
        {isLoading ? (
          <ActivityIndicator color="#FFFFFF" />
        ) : (
          <>
            <CreditCard size={20} color="#FFFFFF" />
            <Text style={styles.payButtonText}>
              Payer avec Stripe
            </Text>
          </>
        )}
      </TouchableOpacity>

      <Text style={[styles.disclaimer, { color: currentColors.textSecondary }]}>
        Vos informations de paiement sont sécurisées et cryptées. MonToit+ ne stocke aucune donnée bancaire.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  paymentInfo: {
    flex: 1,
  },
  amount: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  securityInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    marginBottom: 20,
    gap: 8,
  },
  securityText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
  },
  payButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
    marginBottom: 16,
  },
  payButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  disclaimer: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    lineHeight: 16,
  },
});