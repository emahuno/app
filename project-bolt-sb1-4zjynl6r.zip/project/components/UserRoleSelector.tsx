import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, useColorScheme } from 'react-native';
import { Chrome as Home, Building2, Key } from 'lucide-react-native';

export type UserRole = 'tenant' | 'landlord' | 'owner';

interface UserRoleSelectorProps {
  onRoleSelect: (role: UserRole) => void;
  selectedRole?: UserRole;
}

export function UserRoleSelector({ onRoleSelect, selectedRole }: UserRoleSelectorProps) {
  const colorScheme = useColorScheme();
  const [currentRole, setCurrentRole] = useState<UserRole>(selectedRole || 'tenant');

  const colors = {
    light: {
      primary: '#2563EB',
      secondary: '#10B981',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      secondary: '#34D399',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  const roles = [
    {
      id: 'tenant' as UserRole,
      title: 'Locataire',
      description: 'Je loue un logement',
      icon: Key,
    },
    {
      id: 'landlord' as UserRole,
      title: 'Propriétaire bailleur',
      description: 'Je loue mes biens',
      icon: Building2,
    },
    {
      id: 'owner' as UserRole,
      title: 'Propriétaire',
      description: 'J\'ai un crédit immobilier',
      icon: Home,
    },
  ];

  const handleRolePress = (role: UserRole) => {
    setCurrentRole(role);
    onRoleSelect(role);
  };

  return (
    <View style={styles.container}>
      <Text style={[styles.title, { color: currentColors.text }]}>
        Quel est votre profil ?
      </Text>
      <Text style={[styles.subtitle, { color: currentColors.textSecondary }]}>
        Sélectionnez votre situation pour personnaliser votre expérience
      </Text>
      
      <View style={styles.rolesContainer}>
        {roles.map((role) => {
          const isSelected = currentRole === role.id;
          const IconComponent = role.icon;
          
          return (
            <TouchableOpacity
              key={role.id}
              style={[
                styles.roleCard,
                {
                  backgroundColor: currentColors.card,
                  borderColor: isSelected ? currentColors.primary : currentColors.border,
                  borderWidth: isSelected ? 2 : 1,
                }
              ]}
              onPress={() => handleRolePress(role.id)}
            >
              <View style={[
                styles.iconContainer,
                {
                  backgroundColor: isSelected ? currentColors.primary : currentColors.border,
                }
              ]}>
                <IconComponent 
                  size={24} 
                  color={isSelected ? '#FFFFFF' : currentColors.textSecondary} 
                />
              </View>
              
              <Text style={[
                styles.roleTitle,
                { 
                  color: isSelected ? currentColors.primary : currentColors.text,
                  fontFamily: isSelected ? 'Inter-SemiBold' : 'Inter-Medium',
                }
              ]}>
                {role.title}
              </Text>
              
              <Text style={[styles.roleDescription, { color: currentColors.textSecondary }]}>
                {role.description}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
    paddingVertical: 24,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 24,
  },
  rolesContainer: {
    gap: 16,
  },
  roleCard: {
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  roleTitle: {
    fontSize: 18,
    marginBottom: 8,
    textAlign: 'center',
  },
  roleDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    lineHeight: 20,
  },
});