import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  useColorScheme,
  Alert,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { useStripe, usePaymentSheet } from '@stripe/stripe-react-native';
import { CreditCard, Euro } from 'lucide-react-native';

interface PaymentSheetProps {
  amount: number;
  description: string;
  onPaymentSuccess: (paymentIntentId: string) => void;
  onPaymentError: (error: string) => void;
}

export function PaymentSheet({ 
  amount, 
  description, 
  onPaymentSuccess, 
  onPaymentError 
}: PaymentSheetProps) {
  const colorScheme = useColorScheme();
  const [isLoading, setIsLoading] = useState(false);
  
  // For native platforms
  const { initPaymentSheet, presentPaymentSheet } = usePaymentSheet();

  const colors = {
    light: {
      primary: '#2563EB',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  const handleWebPayment = async () => {
    setIsLoading(true);
    try {
      // For web, we'll redirect to Stripe Checkout
      const response = await fetch('/payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount,
          description,
        }),
      });

      const { clientSecret } = await response.json();

      if (clientSecret) {
        // In a real implementation, you would use Stripe.js for web
        Alert.alert(
          'Paiement',
          'Redirection vers Stripe Checkout...',
          [
            {
              text: 'OK',
              onPress: () => onPaymentSuccess('web_payment_' + Date.now()),
            },
          ]
        );
      }
    } catch (error) {
      onPaymentError('Erreur lors du paiement');
    } finally {
      setIsLoading(false);
    }
  };

  const handleNativePayment = async () => {
    setIsLoading(true);
    try {
      // Create payment intent
      const response = await fetch('/payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount,
          description,
        }),
      });

      const { clientSecret, paymentIntentId } = await response.json();

      if (!clientSecret) {
        throw new Error('Failed to create payment intent');
      }

      // Initialize payment sheet
      const { error: initError } = await initPaymentSheet({
        merchantDisplayName: 'MonToit+',
        paymentIntentClientSecret: clientSecret,
        defaultBillingDetails: {
          name: 'Utilisateur MonToit+',
        },
      });

      if (initError) {
        throw new Error(initError.message);
      }

      // Present payment sheet
      const { error: presentError } = await presentPaymentSheet();

      if (presentError) {
        if (presentError.code !== 'Canceled') {
          throw new Error(presentError.message);
        }
      } else {
        onPaymentSuccess(paymentIntentId);
      }
    } catch (error) {
      onPaymentError(error instanceof Error ? error.message : 'Erreur lors du paiement');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePayment = Platform.OS === 'web' ? handleWebPayment : handleNativePayment;

  return (
    <View style={[styles.container, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
      <View style={styles.header}>
        <View style={[styles.iconContainer, { backgroundColor: currentColors.primary + '20' }]}>
          <Euro size={24} color={currentColors.primary} />
        </View>
        <View style={styles.paymentInfo}>
          <Text style={[styles.amount, { color: currentColors.text }]}>
            {amount.toFixed(2)} €
          </Text>
          <Text style={[styles.description, { color: currentColors.textSecondary }]}>
            {description}
          </Text>
        </View>
      </View>

      <TouchableOpacity
        style={[styles.payButton, { backgroundColor: currentColors.primary }]}
        onPress={handlePayment}
        disabled={isLoading}
      >
        {isLoading ? (
          <ActivityIndicator color="#FFFFFF" />
        ) : (
          <>
            <CreditCard size={20} color="#FFFFFF" />
            <Text style={styles.payButtonText}>
              Payer avec Stripe
            </Text>
          </>
        )}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  paymentInfo: {
    flex: 1,
  },
  amount: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  payButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  payButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
});