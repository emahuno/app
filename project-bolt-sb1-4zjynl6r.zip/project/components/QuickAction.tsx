import React from 'react';
import { TouchableOpacity, Text, StyleSheet, useColorScheme } from 'react-native';
import { Video as LucideIcon } from 'lucide-react-native';

interface QuickActionProps {
  title: string;
  icon: LucideIcon;
  onPress: () => void;
  color?: 'primary' | 'success' | 'warning';
}

export function QuickAction({ title, icon: IconComponent, onPress, color = 'primary' }: QuickActionProps) {
  const colorScheme = useColorScheme();

  const colors = {
    light: {
      primary: '#2563EB',
      success: '#10B981',
      warning: '#F59E0B',
      background: '#FFFFFF',
      text: '#1E293B',
    },
    dark: {
      primary: '#3B82F6',
      success: '#34D399',
      warning: '#FBBF24',
      background: '#0F172A',
      text: '#F1F5F9',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;
  const accentColor = currentColors[color];

  return (
    <TouchableOpacity
      style={[
        styles.container,
        {
          backgroundColor: accentColor,
        }
      ]}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <IconComponent size={20} color="#FFFFFF" />
      <Text style={styles.title}>{title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 12,
    gap: 8,
  },
  title: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
});