import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, useColorScheme } from 'react-native';
import { Video as LucideIcon } from 'lucide-react-native';

interface DashboardCardProps {
  title: string;
  value: string;
  subtitle?: string;
  icon: LucideIcon;
  color?: 'primary' | 'success' | 'warning' | 'danger';
  onPress?: () => void;
}

export function DashboardCard({ 
  title, 
  value, 
  subtitle, 
  icon: IconComponent, 
  color = 'primary',
  onPress 
}: DashboardCardProps) {
  const colorScheme = useColorScheme();

  const colors = {
    light: {
      primary: '#2563EB',
      success: '#10B981',
      warning: '#F59E0B',
      danger: '#EF4444',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      success: '#34D399',
      warning: '#FBBF24',
      danger: '#F87171',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;
  const accentColor = currentColors[color];

  const CardComponent = onPress ? TouchableOpacity : View;

  return (
    <CardComponent
      style={[
        styles.card,
        {
          backgroundColor: currentColors.card,
          borderColor: currentColors.border,
        }
      ]}
      onPress={onPress}
      activeOpacity={onPress ? 0.7 : 1}
    >
      <View style={styles.header}>
        <View style={[styles.iconContainer, { backgroundColor: accentColor + '20' }]}>
          <IconComponent size={20} color={accentColor} />
        </View>
        <Text style={[styles.title, { color: currentColors.textSecondary }]}>
          {title}
        </Text>
      </View>
      
      <Text style={[styles.value, { color: currentColors.text }]}>
        {value}
      </Text>
      
      {subtitle && (
        <Text style={[styles.subtitle, { color: currentColors.textSecondary }]}>
          {subtitle}
        </Text>
      )}
    </CardComponent>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconContainer: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  title: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    flex: 1,
  },
  value: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
    lineHeight: 32,
  },
  subtitle: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    lineHeight: 16,
  },
});