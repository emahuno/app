import React, { useState } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  StyleSheet, 
  useColorScheme,
  SafeAreaView,
  TouchableOpacity,
  Alert,
  Modal
} from 'react-native';
import { CreditCard, Euro, Calendar, CircleCheck as CheckCircle, Clock, CircleAlert as AlertCircle, TrendingUp, Download, Plus } from 'lucide-react-native';
import { StripePaymentForm } from '@/components/StripePaymentForm';

interface Payment {
  id: string;
  amount: string;
  date: string;
  dueDate: string;
  status: 'paid' | 'pending' | 'overdue';
  type: 'rent' | 'mortgage';
  property: string;
  method?: string;
}

export default function PaymentsScreen() {
  const colorScheme = useColorScheme();
  const [activeTab, setActiveTab] = useState<'history' | 'upcoming'>('upcoming');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);

  const colors = {
    light: {
      primary: '#2563EB',
      success: '#10B981',
      warning: '#F59E0B',
      danger: '#EF4444',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      success: '#34D399',
      warning: '#FBBF24',
      danger: '#F87171',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  // Données d'exemple
  const upcomingPayments: Payment[] = [
    {
      id: '1',
      amount: '850',
      date: '',
      dueDate: '2025-01-01',
      status: 'pending',
      type: 'rent',
      property: '12 rue de la République',
    },
    {
      id: '2',
      amount: '1200',
      date: '',
      dueDate: '2025-01-15',
      status: 'pending',
      type: 'mortgage',
      property: '28 rue des Chênes',
    },
  ];

  const paymentHistory: Payment[] = [
    {
      id: '3',
      amount: '850',
      date: '2024-12-01',
      dueDate: '2024-12-01',
      status: 'paid',
      type: 'rent',
      property: '12 rue de la République',
      method: 'Stripe',
    },
    {
      id: '4',
      amount: '1200',
      date: '2024-11-15',
      dueDate: '2024-11-15',
      status: 'paid',
      type: 'mortgage',
      property: '28 rue des Chênes',
      method: 'Stripe',
    },
    {
      id: '5',
      amount: '850',
      date: '2024-11-01',
      dueDate: '2024-11-01',
      status: 'paid',
      type: 'rent',
      property: '12 rue de la République',
      method: 'Stripe',
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return currentColors.success;
      case 'pending':
        return currentColors.warning;
      case 'overdue':
        return currentColors.danger;
      default:
        return currentColors.textSecondary;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid':
        return CheckCircle;
      case 'pending':
        return Clock;
      case 'overdue':
        return AlertCircle;
      default:
        return Clock;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'paid':
        return 'Payé';
      case 'pending':
        return 'En attente';
      case 'overdue':
        return 'En retard';
      default:
        return 'Inconnu';
    }
  };

  const getTypeText = (type: string) => {
    return type === 'rent' ? 'Loyer' : 'Hypothèque';
  };

  const handlePayment = (payment: Payment) => {
    setSelectedPayment(payment);
    setShowPaymentModal(true);
  };

  const handlePaymentSuccess = (paymentIntentId: string) => {
    setShowPaymentModal(false);
    Alert.alert(
      'Paiement réussi',
      'Votre paiement a été traité avec succès via Stripe.',
      [
        {
          text: 'OK',
          onPress: () => {
            // Update payment status in real app
            setSelectedPayment(null);
          },
        },
      ]
    );
  };

  const handlePaymentError = (error: string) => {
    setShowPaymentModal(false);
    Alert.alert('Erreur de paiement', error);
    setSelectedPayment(null);
  };

  const PaymentCard = ({ payment, showActions = false }: { payment: Payment; showActions?: boolean }) => {
    const StatusIcon = getStatusIcon(payment.status);
    
    return (
      <View style={[styles.paymentCard, { 
        backgroundColor: currentColors.card,
        borderColor: currentColors.border,
      }]}>
        <View style={styles.paymentHeader}>
          <View style={styles.paymentInfo}>
            <Text style={[styles.paymentAmount, { color: currentColors.text }]}>
              {payment.amount} €
            </Text>
            <Text style={[styles.paymentType, { color: currentColors.textSecondary }]}>
              {getTypeText(payment.type)} • {payment.property}
            </Text>
          </View>
          <View style={[styles.statusContainer, { backgroundColor: getStatusColor(payment.status) + '20' }]}>
            <StatusIcon size={16} color={getStatusColor(payment.status)} />
            <Text style={[styles.statusText, { color: getStatusColor(payment.status) }]}>
              {getStatusText(payment.status)}
            </Text>
          </View>
        </View>

        <View style={styles.paymentDetails}>
          <View style={styles.detailRow}>
            <Calendar size={16} color={currentColors.textSecondary} />
            <Text style={[styles.detailText, { color: currentColors.textSecondary }]}>
              {payment.status === 'paid' 
                ? `Payé le ${new Date(payment.date).toLocaleDateString('fr-FR')}`
                : `Échéance le ${new Date(payment.dueDate).toLocaleDateString('fr-FR')}`
              }
            </Text>
          </View>
          
          {payment.method && (
            <View style={styles.detailRow}>
              <CreditCard size={16} color={currentColors.textSecondary} />
              <Text style={[styles.detailText, { color: currentColors.textSecondary }]}>
                Payé via {payment.method}
              </Text>
            </View>
          )}
        </View>

        {showActions && payment.status === 'pending' && (
          <View style={styles.paymentActions}>
            <TouchableOpacity
              style={[styles.payButton, { backgroundColor: currentColors.primary }]}
              onPress={() => handlePayment(payment)}
            >
              <Euro size={16} color="#FFFFFF" />
              <Text style={styles.payButtonText}>Payer avec Stripe</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: currentColors.text }]}>
          Paiements
        </Text>
        <TouchableOpacity
          style={[styles.addButton, { backgroundColor: currentColors.primary }]}
          onPress={() => Alert.alert('Nouveau paiement', 'Fonctionnalité bientôt disponible')}
        >
          <Plus size={20} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'upcoming' && { backgroundColor: currentColors.primary + '20' }
          ]}
          onPress={() => setActiveTab('upcoming')}
        >
          <Text style={[
            styles.tabText,
            { color: activeTab === 'upcoming' ? currentColors.primary : currentColors.textSecondary }
          ]}>
            À venir
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'history' && { backgroundColor: currentColors.primary + '20' }
          ]}
          onPress={() => setActiveTab('history')}
        >
          <Text style={[
            styles.tabText,
            { color: activeTab === 'history' ? currentColors.primary : currentColors.textSecondary }
          ]}>
            Historique
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView 
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
      >
        {activeTab === 'upcoming' && (
          <>
            <View style={styles.summaryCard}>
              <View style={[styles.summaryItem, { backgroundColor: currentColors.card }]}>
                <TrendingUp size={24} color={currentColors.primary} />
                <View style={styles.summaryText}>
                  <Text style={[styles.summaryLabel, { color: currentColors.textSecondary }]}>
                    Total à payer
                  </Text>
                  <Text style={[styles.summaryValue, { color: currentColors.text }]}>
                    2 050 €
                  </Text>
                </View>
              </View>
            </View>

            {upcomingPayments.map((payment) => (
              <PaymentCard key={payment.id} payment={payment} showActions={true} />
            ))}
          </>
        )}

        {activeTab === 'history' && (
          <>
            <View style={styles.summaryCard}>
              <View style={[styles.summaryItem, { backgroundColor: currentColors.card }]}>
                <Download size={24} color={currentColors.success} />
                <View style={styles.summaryText}>
                  <Text style={[styles.summaryLabel, { color: currentColors.textSecondary }]}>
                    Total payé cette année
                  </Text>
                  <Text style={[styles.summaryValue, { color: currentColors.text }]}>
                    24 600 €
                  </Text>
                </View>
                <TouchableOpacity
                  style={[styles.exportButton, { backgroundColor: currentColors.success + '20' }]}
                  onPress={() => Alert.alert('Export', 'Téléchargement du relevé')}
                >
                  <Download size={16} color={currentColors.success} />
                </TouchableOpacity>
              </View>
            </View>

            {paymentHistory.map((payment) => (
              <PaymentCard key={payment.id} payment={payment} />
            ))}
          </>
        )}
      </ScrollView>

      {/* Payment Modal */}
      <Modal
        visible={showPaymentModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowPaymentModal(false)}
      >
        <SafeAreaView style={[styles.modalContainer, { backgroundColor: currentColors.background }]}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setShowPaymentModal(false)}>
              <Text style={[styles.modalCancel, { color: currentColors.textSecondary }]}>
                Annuler
              </Text>
            </TouchableOpacity>
            <Text style={[styles.modalTitle, { color: currentColors.text }]}>
              Paiement sécurisé
            </Text>
            <View style={{ width: 60 }} />
          </View>

          <View style={styles.modalContent}>
            {selectedPayment && (
              <StripePaymentForm
                amount={parseFloat(selectedPayment.amount)}
                description={`${getTypeText(selectedPayment.type)} - ${selectedPayment.property}`}
                onPaymentSuccess={handlePaymentSuccess}
                onPaymentError={handlePaymentError}
                customerEmail="marie.dubois@email.com"
              />
            )}
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
  },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabs: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
    gap: 8,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  tabText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  summaryCard: {
    marginBottom: 20,
  },
  summaryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    borderRadius: 16,
    gap: 16,
  },
  summaryText: {
    flex: 1,
  },
  summaryLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    marginBottom: 4,
  },
  summaryValue: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
  },
  exportButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  paymentCard: {
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  paymentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  paymentInfo: {
    flex: 1,
  },
  paymentAmount: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
  },
  paymentType: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    gap: 6,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
  },
  paymentDetails: {
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    marginLeft: 8,
    flex: 1,
  },
  paymentActions: {
    marginTop: 8,
  },
  payButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  payButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  modalCancel: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
  },
  modalTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
  },
  modalContent: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
});