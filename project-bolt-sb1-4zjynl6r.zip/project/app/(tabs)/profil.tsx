import React from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  StyleSheet, 
  useColorScheme,
  SafeAreaView,
  TouchableOpacity,
  Alert,
  Switch
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { User, Settings, Bell, Shield, CircleHelp as HelpCircle, LogOut, ChevronRight, Moon, Sun, CreditCard, FileText, Mail, Phone, MapPin, CreditCard as Edit3, MessageCircle, Crown } from 'lucide-react-native';

export default function ProfileScreen() {
  const colorScheme = useColorScheme();
  const { user, logout } = useAuth();
  const [notificationsEnabled, setNotificationsEnabled] = React.useState(true);
  const [darkModeEnabled, setDarkModeEnabled] = React.useState(colorScheme === 'dark');

  const colors = {
    light: {
      primary: '#2563EB',
      success: '#10B981',
      warning: '#F59E0B',
      danger: '#EF4444',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      success: '#34D399',
      warning: '#FBBF24',
      danger: '#F87171',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  const handleMenuPress = (item: string) => {
    switch (item) {
      case 'Modifier le profil':
        router.push('/(tabs)/edit-profile');
        break;
      case 'Moyens de paiement':
        router.push('/(tabs)/payment-methods');
        break;
      case 'Messages':
        if (user?.role === 'tenant') {
          router.push('/(tabs)/messages');
        } else {
          Alert.alert('Messages', 'Fonctionnalité bientôt disponible');
        }
        break;
      case 'Abonnement':
        Alert.alert('Abonnement Réparation', 'Abonnement à 75€/mois pour les réparations et rénovations');
        break;
      default:
        Alert.alert('Navigation', `${item} sera bientôt disponible`);
    }
  };

  const handleLogout = () => {
    Alert.alert(
      'Déconnexion',
      'Êtes-vous sûr de vouloir vous déconnecter ?',
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Se déconnecter', style: 'destructive', onPress: logout },
      ]
    );
  };

  const getRoleText = (role: string) => {
    switch (role) {
      case 'tenant':
        return 'Locataire';
      case 'landlord':
        return 'Propriétaire bailleur';
      case 'owner':
        return 'Propriétaire';
      default:
        return 'Utilisateur';
    }
  };

  const MenuItem = ({ 
    icon: IconComponent, 
    title, 
    subtitle, 
    onPress, 
    showChevron = true,
    color = currentColors.textSecondary,
    rightElement 
  }: {
    icon: any;
    title: string;
    subtitle?: string;
    onPress: () => void;
    showChevron?: boolean;
    color?: string;
    rightElement?: React.ReactNode;
  }) => (
    <TouchableOpacity
      style={[styles.menuItem, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={[styles.menuIconContainer, { backgroundColor: color + '20' }]}>
        <IconComponent size={20} color={color} />
      </View>
      
      <View style={styles.menuContent}>
        <Text style={[styles.menuTitle, { color: currentColors.text }]}>
          {title}
        </Text>
        {subtitle && (
          <Text style={[styles.menuSubtitle, { color: currentColors.textSecondary }]}>
            {subtitle}
          </Text>
        )}
      </View>
      
      {rightElement ? rightElement : (
        showChevron && <ChevronRight size={20} color={currentColors.textSecondary} />
      )}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <View style={[styles.profileHeader, { backgroundColor: currentColors.card }]}>
          <View style={[styles.avatarContainer, { backgroundColor: currentColors.primary + '20' }]}>
            <User size={32} color={currentColors.primary} />
          </View>
          
          <View style={styles.profileInfo}>
            <Text style={[styles.profileName, { color: currentColors.text }]}>
              {user?.firstName} {user?.lastName}
            </Text>
            <Text style={[styles.profileRole, { color: currentColors.textSecondary }]}>
              {getRoleText(user?.role || '')}
            </Text>
          </View>
          
          <TouchableOpacity
            style={[styles.editButton, { backgroundColor: currentColors.primary + '20' }]}
            onPress={() => handleMenuPress('Modifier le profil')}
          >
            <Edit3 size={16} color={currentColors.primary} />
          </TouchableOpacity>
        </View>

        {/* Contact Info */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: currentColors.text }]}>
            Informations personnelles
          </Text>
          
          <MenuItem
            icon={Mail}
            title={user?.email || ''}
            onPress={() => handleMenuPress('Email')}
            color={currentColors.primary}
          />
          
          <MenuItem
            icon={Phone}
            title={user?.phone || ''}
            onPress={() => handleMenuPress('Téléphone')}
            color={currentColors.success}
          />
          
          <MenuItem
            icon={MapPin}
            title={user?.address || ''}
            subtitle="Adresse principale"
            onPress={() => handleMenuPress('Adresse')}
            color={currentColors.warning}
          />
        </View>

        {/* Messages pour locataires */}
        {user?.role === 'tenant' && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: currentColors.text }]}>
              Communication
            </Text>
            
            <MenuItem
              icon={MessageCircle}
              title="Messages"
              subtitle="Contacter votre propriétaire"
              onPress={() => handleMenuPress('Messages')}
              color={currentColors.primary}
            />
          </View>
        )}

        {/* Abonnement pour propriétaires bailleurs */}
        {user?.role === 'landlord' && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: currentColors.text }]}>
              Services
            </Text>
            
            <MenuItem
              icon={Crown}
              title="Abonnement Réparation"
              subtitle="75€/mois - Réparations et rénovations"
              onPress={() => handleMenuPress('Abonnement')}
              color={currentColors.warning}
            />
          </View>
        )}

        {/* Settings */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: currentColors.text }]}>
            Paramètres
          </Text>
          
          <MenuItem
            icon={Bell}
            title="Notifications"
            subtitle="Rappels de paiement et alertes"
            onPress={() => {}}
            showChevron={false}
            color={currentColors.primary}
            rightElement={
              <Switch
                value={notificationsEnabled}
                onValueChange={setNotificationsEnabled}
                trackColor={{ false: currentColors.border, true: currentColors.primary + '40' }}
                thumbColor={notificationsEnabled ? currentColors.primary : currentColors.textSecondary}
              />
            }
          />
          
          <MenuItem
            icon={colorScheme === 'dark' ? Moon : Sun}
            title="Mode sombre"
            subtitle="Thème de l'application"
            onPress={() => {}}
            showChevron={false}
            color={currentColors.warning}
            rightElement={
              <Switch
                value={darkModeEnabled}
                onValueChange={setDarkModeEnabled}
                trackColor={{ false: currentColors.border, true: currentColors.warning + '40' }}
                thumbColor={darkModeEnabled ? currentColors.warning : currentColors.textSecondary}
              />
            }
          />
          
          <MenuItem
            icon={CreditCard}
            title="Moyens de paiement"
            subtitle="Cartes et comptes bancaires"
            onPress={() => handleMenuPress('Moyens de paiement')}
            color={currentColors.success}
          />
        </View>

        {/* App */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: currentColors.text }]}>
            Application
          </Text>
          
          <MenuItem
            icon={Shield}
            title="Sécurité et confidentialité"
            subtitle="Paramètres de sécurité"
            onPress={() => handleMenuPress('Sécurité')}
            color={currentColors.primary}
          />
          
          <MenuItem
            icon={FileText}
            title="Conditions d'utilisation"
            onPress={() => handleMenuPress('Conditions')}
            color={currentColors.textSecondary}
          />
          
          <MenuItem
            icon={HelpCircle}
            title="Aide et support"
            subtitle="FAQ et contact support"
            onPress={() => handleMenuPress('Aide')}
            color={currentColors.warning}
          />
        </View>

        {/* Logout */}
        <View style={styles.section}>
          <MenuItem
            icon={LogOut}
            title="Se déconnecter"
            onPress={handleLogout}
            color={currentColors.danger}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  profileHeader: {
    padding: 20,
    marginHorizontal: 20,
    marginTop: 20,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  avatarContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileInfo: {
    flex: 1,
    marginLeft: 16,
  },
  profileName: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
  },
  profileRole: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  editButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  section: {
    marginTop: 32,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 16,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
    borderWidth: 1,
  },
  menuIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuContent: {
    flex: 1,
    marginLeft: 12,
  },
  menuTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    marginBottom: 2,
  },
  menuSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
});