import React from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  StyleSheet, 
  useColorScheme,
  SafeAreaView,
  Alert
} from 'react-native';
import { Chrome as Home, Euro, FileText, Bell, TrendingUp, Calendar, Plus, CreditCard, Upload } from 'lucide-react-native';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import { DashboardCard } from '@/components/DashboardCard';
import { QuickAction } from '@/components/QuickAction';

export default function HomeScreen() {
  const colorScheme = useColorScheme();
  const { user } = useAuth();

  const colors = {
    light: {
      primary: '#2563EB',
      secondary: '#10B981',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      secondary: '#34D399',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  const handleQuickAction = (action: string) => {
    Alert.alert('Action', `${action} sera bientôt disponible`);
  };

  const getDashboardData = (role: UserRole) => {
    switch (role) {
      case 'tenant':
        return {
          cards: [
            {
              title: 'Loyer mensuel',
              value: '850 €',
              subtitle: 'Prochain paiement le 1er janvier',
              icon: Euro,
              color: 'primary' as const,
            },
            {
              title: 'Contrat de location',
              value: 'Actif',
              subtitle: 'Expire le 15 juin 2025',
              icon: FileText,
              color: 'success' as const,
            },
            {
              title: 'Historique des paiements',
              value: '12/12',
              subtitle: 'Paiements effectués cette année',
              icon: TrendingUp,
              color: 'success' as const,
            },
          ],
          quickActions: [
            { title: 'Payer le loyer', icon: CreditCard, color: 'primary' as const },
            { title: 'Télécharger reçu', icon: Upload, color: 'success' as const },
          ]
        };
      
      case 'landlord':
        return {
          cards: [
            {
              title: 'Revenus mensuels',
              value: '2 450 €',
              subtitle: 'De 3 propriétés',
              icon: Euro,
              color: 'success' as const,
            },
            {
              title: 'Propriétés gérées',
              value: '3',
              subtitle: 'Toutes occupées',
              icon: Home,
              color: 'primary' as const,
            },
            {
              title: 'Paiements en attente',
              value: '1',
              subtitle: 'Appartement rue de la Paix',
              icon: Bell,
              color: 'warning' as const,
            },
            {
              title: 'Compte MonToit',
              value: '1 850 €',
              subtitle: 'Disponible pour transfert',
              icon: TrendingUp,
              color: 'success' as const,
            },
          ],
          quickActions: [
            { title: 'Ajouter propriété', icon: Plus, color: 'primary' as const },
            { title: 'Transférer fonds', icon: Upload, color: 'success' as const },
          ]
        };
      
      case 'owner':
        return {
          cards: [
            {
              title: 'Mensualité hypothèque',
              value: '1 200 €',
              subtitle: 'Prochain paiement le 15 janvier',
              icon: Euro,
              color: 'primary' as const,
            },
            {
              title: 'Capital restant',
              value: '180 000 €',
              subtitle: 'Sur 250 000 € initial',
              icon: TrendingUp,
              color: 'warning' as const,
            },
            {
              title: 'Progression',
              value: '28%',
              subtitle: 'Du crédit remboursé',
              icon: Calendar,
              color: 'success' as const,
            },
          ],
          quickActions: [
            { title: 'Effectuer paiement', icon: CreditCard, color: 'primary' as const },
            { title: 'Voir échéancier', icon: Calendar, color: 'success' as const },
          ]
        };
    }
  };

  if (!user) {
    return null;
  }

  const dashboardData = getDashboardData(user.role);

  const getWelcomeMessage = (role: UserRole) => {
    const messages = {
      tenant: 'Bonjour ! Gérez facilement votre location.',
      landlord: 'Bonjour ! Suivez vos propriétés en un coup d\'œil.',
      owner: 'Bonjour ! Suivez votre crédit immobilier.',
    };
    return messages[role];
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <ScrollView 
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={[styles.welcome, { color: currentColors.text }]}>
            {getWelcomeMessage(user.role)}
          </Text>
          <Text style={[styles.date, { color: currentColors.textSecondary }]}>
            {new Date().toLocaleDateString('fr-FR', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: currentColors.text }]}>
            Vue d'ensemble
          </Text>
          {dashboardData.cards.map((card, index) => (
            <DashboardCard
              key={index}
              title={card.title}
              value={card.value}
              subtitle={card.subtitle}
              icon={card.icon}
              color={card.color}
            />
          ))}
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: currentColors.text }]}>
            Actions rapides
          </Text>
          <View style={styles.quickActions}>
            {dashboardData.quickActions.map((action, index) => (
              <QuickAction
                key={index}
                title={action.title}
                icon={action.icon}
                color={action.color}
                onPress={() => handleQuickAction(action.title)}
              />
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  header: {
    paddingTop: 20,
    paddingBottom: 32,
  },
  welcome: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
    lineHeight: 34,
  },
  date: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    textTransform: 'capitalize',
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 16,
  },
  quickActions: {
    gap: 12,
  },
});