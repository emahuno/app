import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  useColorScheme,
  SafeAreaView,
  ScrollView,
  Alert,
  ActivityIndicator,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Chrome as Home, MapPin, Euro, Calendar, User, Camera, Plus, X, Check } from 'lucide-react-native';

interface PropertyData {
  title: string;
  address: string;
  city: string;
  postalCode: string;
  type: 'apartment' | 'house' | 'studio' | 'room';
  surface: string;
  rooms: string;
  bedrooms: string;
  bathrooms: string;
  monthlyRent: string;
  charges: string;
  deposit: string;
  description: string;
  amenities: string[];
  photos: string[];
  tenantEmail: string;
  tenantName: string;
  leaseStartDate: string;
  leaseEndDate: string;
}

export default function AddPropertyScreen() {
  const colorScheme = useColorScheme();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<PropertyData>({
    title: '',
    address: '',
    city: '',
    postalCode: '',
    type: 'apartment',
    surface: '',
    rooms: '',
    bedrooms: '',
    bathrooms: '',
    monthlyRent: '',
    charges: '',
    deposit: '',
    description: '',
    amenities: [],
    photos: [],
    tenantEmail: '',
    tenantName: '',
    leaseStartDate: '',
    leaseEndDate: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const colors = {
    light: {
      primary: '#2563EB',
      success: '#10B981',
      warning: '#F59E0B',
      danger: '#EF4444',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      success: '#34D399',
      warning: '#FBBF24',
      danger: '#F87171',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  const propertyTypes = [
    { id: 'apartment', label: 'Appartement', icon: '🏢' },
    { id: 'house', label: 'Maison', icon: '🏠' },
    { id: 'studio', label: 'Studio', icon: '🏠' },
    { id: 'room', label: 'Chambre', icon: '🚪' },
  ];

  const availableAmenities = [
    'Balcon', 'Terrasse', 'Jardin', 'Parking', 'Cave', 'Ascenseur',
    'Climatisation', 'Chauffage', 'Lave-vaisselle', 'Lave-linge',
    'Internet', 'Meublé', 'Animaux acceptés', 'Fumeurs acceptés'
  ];

  const samplePhotos = [
    'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/1571453/pexels-photo-1571453.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/2121121/pexels-photo-2121121.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/1457842/pexels-photo-1457842.jpeg?auto=compress&cs=tinysrgb&w=400',
  ];

  const updateFormData = (field: keyof PropertyData, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const toggleAmenity = (amenity: string) => {
    const currentAmenities = formData.amenities;
    const newAmenities = currentAmenities.includes(amenity)
      ? currentAmenities.filter(a => a !== amenity)
      : [...currentAmenities, amenity];
    updateFormData('amenities', newAmenities);
  };

  const addSamplePhoto = () => {
    const availablePhotos = samplePhotos.filter(photo => !formData.photos.includes(photo));
    if (availablePhotos.length > 0) {
      const randomPhoto = availablePhotos[Math.floor(Math.random() * availablePhotos.length)];
      updateFormData('photos', [...formData.photos, randomPhoto]);
    }
  };

  const removePhoto = (photoUrl: string) => {
    updateFormData('photos', formData.photos.filter(p => p !== photoUrl));
  };

  const validateStep = (step: number) => {
    const newErrors: Record<string, string> = {};

    switch (step) {
      case 1:
        if (!formData.title) newErrors.title = 'Le titre est requis';
        if (!formData.address) newErrors.address = 'L\'adresse est requise';
        if (!formData.city) newErrors.city = 'La ville est requise';
        if (!formData.postalCode) newErrors.postalCode = 'Le code postal est requis';
        break;
      case 2:
        if (!formData.surface) newErrors.surface = 'La surface est requise';
        if (!formData.rooms) newErrors.rooms = 'Le nombre de pièces est requis';
        if (!formData.bedrooms) newErrors.bedrooms = 'Le nombre de chambres est requis';
        break;
      case 3:
        if (!formData.monthlyRent) newErrors.monthlyRent = 'Le loyer mensuel est requis';
        if (!formData.deposit) newErrors.deposit = 'Le dépôt de garantie est requis';
        break;
      case 4:
        if (!formData.tenantName) newErrors.tenantName = 'Le nom du locataire est requis';
        if (!formData.tenantEmail) newErrors.tenantEmail = 'L\'email du locataire est requis';
        if (!formData.leaseStartDate) newErrors.leaseStartDate = 'La date de début est requise';
        if (!formData.leaseEndDate) newErrors.leaseEndDate = 'La date de fin est requise';
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => prev - 1);
  };

  const handleSubmit = async () => {
    if (!validateStep(currentStep)) return;

    setIsLoading(true);
    try {
      // Simuler la création de la propriété
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      Alert.alert(
        'Propriété ajoutée',
        'Votre propriété a été ajoutée avec succès ! Le locataire recevra une invitation par email.',
        [{ text: 'OK', onPress: () => router.back() }]
      );
    } catch (error) {
      Alert.alert('Erreur', 'Une erreur est survenue lors de l\'ajout de la propriété');
    } finally {
      setIsLoading(false);
    }
  };

  const renderStepIndicator = () => (
    <View style={styles.stepIndicator}>
      {[1, 2, 3, 4, 5].map((step) => (
        <View key={step} style={styles.stepContainer}>
          <View style={[
            styles.stepCircle,
            {
              backgroundColor: step <= currentStep ? currentColors.primary : currentColors.border,
            }
          ]}>
            {step < currentStep ? (
              <Check size={16} color="#FFFFFF" />
            ) : (
              <Text style={[
                styles.stepNumber,
                { color: step <= currentStep ? '#FFFFFF' : currentColors.textSecondary }
              ]}>
                {step}
              </Text>
            )}
          </View>
          {step < 5 && (
            <View style={[
              styles.stepLine,
              { backgroundColor: step < currentStep ? currentColors.primary : currentColors.border }
            ]} />
          )}
        </View>
      ))}
    </View>
  );

  const renderStep1 = () => (
    <View style={styles.stepContent}>
      <Text style={[styles.stepTitle, { color: currentColors.text }]}>
        Informations générales
      </Text>

      <View style={styles.inputContainer}>
        <Text style={[styles.label, { color: currentColors.text }]}>Titre de l'annonce</Text>
        <TextInput
          style={[styles.input, { color: currentColors.text, borderColor: errors.title ? currentColors.danger : currentColors.border }]}
          placeholder="Ex: Bel appartement T3 centre-ville"
          placeholderTextColor={currentColors.textSecondary}
          value={formData.title}
          onChangeText={(value) => updateFormData('title', value)}
        />
        {errors.title && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.title}</Text>}
      </View>

      <View style={styles.inputContainer}>
        <Text style={[styles.label, { color: currentColors.text }]}>Type de bien</Text>
        <View style={styles.typeSelector}>
          {propertyTypes.map((type) => (
            <TouchableOpacity
              key={type.id}
              style={[
                styles.typeOption,
                {
                  backgroundColor: formData.type === type.id ? currentColors.primary + '20' : currentColors.card,
                  borderColor: formData.type === type.id ? currentColors.primary : currentColors.border,
                }
              ]}
              onPress={() => updateFormData('type', type.id as any)}
            >
              <Text style={styles.typeEmoji}>{type.icon}</Text>
              <Text style={[
                styles.typeOptionText,
                { color: formData.type === type.id ? currentColors.primary : currentColors.text }
              ]}>
                {type.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.inputContainer}>
        <Text style={[styles.label, { color: currentColors.text }]}>Adresse</Text>
        <TextInput
          style={[styles.input, { color: currentColors.text, borderColor: errors.address ? currentColors.danger : currentColors.border }]}
          placeholder="Numéro et nom de rue"
          placeholderTextColor={currentColors.textSecondary}
          value={formData.address}
          onChangeText={(value) => updateFormData('address', value)}
        />
        {errors.address && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.address}</Text>}
      </View>

      <View style={styles.row}>
        <View style={[styles.inputContainer, { flex: 2 }]}>
          <Text style={[styles.label, { color: currentColors.text }]}>Ville</Text>
          <TextInput
            style={[styles.input, { color: currentColors.text, borderColor: errors.city ? currentColors.danger : currentColors.border }]}
            placeholder="Ville"
            placeholderTextColor={currentColors.textSecondary}
            value={formData.city}
            onChangeText={(value) => updateFormData('city', value)}
          />
          {errors.city && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.city}</Text>}
        </View>

        <View style={[styles.inputContainer, { flex: 1 }]}>
          <Text style={[styles.label, { color: currentColors.text }]}>Code postal</Text>
          <TextInput
            style={[styles.input, { color: currentColors.text, borderColor: errors.postalCode ? currentColors.danger : currentColors.border }]}
            placeholder="75001"
            placeholderTextColor={currentColors.textSecondary}
            value={formData.postalCode}
            onChangeText={(value) => updateFormData('postalCode', value)}
            keyboardType="numeric"
            maxLength={5}
          />
          {errors.postalCode && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.postalCode}</Text>}
        </View>
      </View>
    </View>
  );

  const renderStep2 = () => (
    <View style={styles.stepContent}>
      <Text style={[styles.stepTitle, { color: currentColors.text }]}>
        Caractéristiques du bien
      </Text>

      <View style={styles.row}>
        <View style={[styles.inputContainer, { flex: 1 }]}>
          <Text style={[styles.label, { color: currentColors.text }]}>Surface (m²)</Text>
          <TextInput
            style={[styles.input, { color: currentColors.text, borderColor: errors.surface ? currentColors.danger : currentColors.border }]}
            placeholder="65"
            placeholderTextColor={currentColors.textSecondary}
            value={formData.surface}
            onChangeText={(value) => updateFormData('surface', value)}
            keyboardType="numeric"
          />
          {errors.surface && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.surface}</Text>}
        </View>

        <View style={[styles.inputContainer, { flex: 1 }]}>
          <Text style={[styles.label, { color: currentColors.text }]}>Pièces</Text>
          <TextInput
            style={[styles.input, { color: currentColors.text, borderColor: errors.rooms ? currentColors.danger : currentColors.border }]}
            placeholder="3"
            placeholderTextColor={currentColors.textSecondary}
            value={formData.rooms}
            onChangeText={(value) => updateFormData('rooms', value)}
            keyboardType="numeric"
          />
          {errors.rooms && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.rooms}</Text>}
        </View>
      </View>

      <View style={styles.row}>
        <View style={[styles.inputContainer, { flex: 1 }]}>
          <Text style={[styles.label, { color: currentColors.text }]}>Chambres</Text>
          <TextInput
            style={[styles.input, { color: currentColors.text, borderColor: errors.bedrooms ? currentColors.danger : currentColors.border }]}
            placeholder="2"
            placeholderTextColor={currentColors.textSecondary}
            value={formData.bedrooms}
            onChangeText={(value) => updateFormData('bedrooms', value)}
            keyboardType="numeric"
          />
          {errors.bedrooms && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.bedrooms}</Text>}
        </View>

        <View style={[styles.inputContainer, { flex: 1 }]}>
          <Text style={[styles.label, { color: currentColors.text }]}>Salles de bain</Text>
          <TextInput
            style={[styles.input, { color: currentColors.text, borderColor: errors.bathrooms ? currentColors.danger : currentColors.border }]}
            placeholder="1"
            placeholderTextColor={currentColors.textSecondary}
            value={formData.bathrooms}
            onChangeText={(value) => updateFormData('bathrooms', value)}
            keyboardType="numeric"
          />
        </View>
      </View>

      <View style={styles.inputContainer}>
        <Text style={[styles.label, { color: currentColors.text }]}>Description</Text>
        <TextInput
          style={[styles.textArea, { color: currentColors.text, borderColor: currentColors.border }]}
          placeholder="Décrivez votre bien (équipements, localisation, points forts...)"
          placeholderTextColor={currentColors.textSecondary}
          value={formData.description}
          onChangeText={(value) => updateFormData('description', value)}
          multiline
          numberOfLines={4}
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={[styles.label, { color: currentColors.text }]}>Équipements et services</Text>
        <View style={styles.amenitiesGrid}>
          {availableAmenities.map((amenity) => (
            <TouchableOpacity
              key={amenity}
              style={[
                styles.amenityChip,
                {
                  backgroundColor: formData.amenities.includes(amenity) ? currentColors.primary + '20' : currentColors.card,
                  borderColor: formData.amenities.includes(amenity) ? currentColors.primary : currentColors.border,
                }
              ]}
              onPress={() => toggleAmenity(amenity)}
            >
              <Text style={[
                styles.amenityText,
                { color: formData.amenities.includes(amenity) ? currentColors.primary : currentColors.text }
              ]}>
                {amenity}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </View>
  );

  const renderStep3 = () => (
    <View style={styles.stepContent}>
      <Text style={[styles.stepTitle, { color: currentColors.text }]}>
        Informations financières
      </Text>

      <View style={styles.inputContainer}>
        <Text style={[styles.label, { color: currentColors.text }]}>Loyer mensuel (€)</Text>
        <View style={[styles.inputWrapper, { borderColor: errors.monthlyRent ? currentColors.danger : currentColors.border }]}>
          <Euro size={20} color={currentColors.textSecondary} />
          <TextInput
            style={[styles.inputWithIcon, { color: currentColors.text }]}
            placeholder="850"
            placeholderTextColor={currentColors.textSecondary}
            value={formData.monthlyRent}
            onChangeText={(value) => updateFormData('monthlyRent', value)}
            keyboardType="numeric"
          />
        </View>
        {errors.monthlyRent && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.monthlyRent}</Text>}
      </View>

      <View style={styles.inputContainer}>
        <Text style={[styles.label, { color: currentColors.text }]}>Charges mensuelles (€)</Text>
        <View style={[styles.inputWrapper, { borderColor: currentColors.border }]}>
          <Euro size={20} color={currentColors.textSecondary} />
          <TextInput
            style={[styles.inputWithIcon, { color: currentColors.text }]}
            placeholder="120"
            placeholderTextColor={currentColors.textSecondary}
            value={formData.charges}
            onChangeText={(value) => updateFormData('charges', value)}
            keyboardType="numeric"
          />
        </View>
      </View>

      <View style={styles.inputContainer}>
        <Text style={[styles.label, { color: currentColors.text }]}>Dépôt de garantie (€)</Text>
        <View style={[styles.inputWrapper, { borderColor: errors.deposit ? currentColors.danger : currentColors.border }]}>
          <Euro size={20} color={currentColors.textSecondary} />
          <TextInput
            style={[styles.inputWithIcon, { color: currentColors.text }]}
            placeholder="1700"
            placeholderTextColor={currentColors.textSecondary}
            value={formData.deposit}
            onChangeText={(value) => updateFormData('deposit', value)}
            keyboardType="numeric"
          />
        </View>
        {errors.deposit && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.deposit}</Text>}
      </View>

      <View style={[styles.summaryCard, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
        <Text style={[styles.summaryTitle, { color: currentColors.text }]}>Récapitulatif financier</Text>
        <View style={styles.summaryRow}>
          <Text style={[styles.summaryLabel, { color: currentColors.textSecondary }]}>Loyer mensuel</Text>
          <Text style={[styles.summaryValue, { color: currentColors.text }]}>
            {formData.monthlyRent ? `${formData.monthlyRent}€` : '-'}
          </Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={[styles.summaryLabel, { color: currentColors.textSecondary }]}>Charges</Text>
          <Text style={[styles.summaryValue, { color: currentColors.text }]}>
            {formData.charges ? `${formData.charges}€` : '-'}
          </Text>
        </View>
        <View style={[styles.summaryRow, styles.summaryTotal]}>
          <Text style={[styles.summaryLabel, { color: currentColors.text, fontFamily: 'Inter-SemiBold' }]}>Total mensuel</Text>
          <Text style={[styles.summaryValue, { color: currentColors.primary, fontFamily: 'Inter-Bold' }]}>
            {formData.monthlyRent && formData.charges 
              ? `${parseInt(formData.monthlyRent) + parseInt(formData.charges)}€`
              : formData.monthlyRent ? `${formData.monthlyRent}€` : '-'
            }
          </Text>
        </View>
      </View>
    </View>
  );

  const renderStep4 = () => (
    <View style={styles.stepContent}>
      <Text style={[styles.stepTitle, { color: currentColors.text }]}>
        Photos du bien
      </Text>

      <View style={styles.photosSection}>
        <TouchableOpacity
          style={[styles.addPhotoButton, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}
          onPress={addSamplePhoto}
        >
          <Camera size={24} color={currentColors.textSecondary} />
          <Text style={[styles.addPhotoText, { color: currentColors.textSecondary }]}>
            Ajouter une photo
          </Text>
        </TouchableOpacity>

        <View style={styles.photosGrid}>
          {formData.photos.map((photo, index) => (
            <View key={index} style={styles.photoContainer}>
              <Image source={{ uri: photo }} style={styles.photo} />
              <TouchableOpacity
                style={[styles.removePhotoButton, { backgroundColor: currentColors.danger }]}
                onPress={() => removePhoto(photo)}
              >
                <X size={16} color="#FFFFFF" />
              </TouchableOpacity>
            </View>
          ))}
        </View>

        {formData.photos.length === 0 && (
          <Text style={[styles.noPhotosText, { color: currentColors.textSecondary }]}>
            Aucune photo ajoutée. Les photos aident à attirer les locataires.
          </Text>
        )}
      </View>
    </View>
  );

  const renderStep5 = () => (
    <View style={styles.stepContent}>
      <Text style={[styles.stepTitle, { color: currentColors.text }]}>
        Informations du locataire
      </Text>

      <View style={styles.inputContainer}>
        <Text style={[styles.label, { color: currentColors.text }]}>Nom complet du locataire</Text>
        <View style={[styles.inputWrapper, { borderColor: errors.tenantName ? currentColors.danger : currentColors.border }]}>
          <User size={20} color={currentColors.textSecondary} />
          <TextInput
            style={[styles.inputWithIcon, { color: currentColors.text }]}
            placeholder="Marie Dubois"
            placeholderTextColor={currentColors.textSecondary}
            value={formData.tenantName}
            onChangeText={(value) => updateFormData('tenantName', value)}
          />
        </View>
        {errors.tenantName && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.tenantName}</Text>}
      </View>

      <View style={styles.inputContainer}>
        <Text style={[styles.label, { color: currentColors.text }]}>Email du locataire</Text>
        <TextInput
          style={[styles.input, { color: currentColors.text, borderColor: errors.tenantEmail ? currentColors.danger : currentColors.border }]}
          placeholder="marie.dubois@email.com"
          placeholderTextColor={currentColors.textSecondary}
          value={formData.tenantEmail}
          onChangeText={(value) => updateFormData('tenantEmail', value)}
          keyboardType="email-address"
          autoCapitalize="none"
        />
        {errors.tenantEmail && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.tenantEmail}</Text>}
      </View>

      <View style={styles.row}>
        <View style={[styles.inputContainer, { flex: 1 }]}>
          <Text style={[styles.label, { color: currentColors.text }]}>Date de début</Text>
          <View style={[styles.inputWrapper, { borderColor: errors.leaseStartDate ? currentColors.danger : currentColors.border }]}>
            <Calendar size={20} color={currentColors.textSecondary} />
            <TextInput
              style={[styles.inputWithIcon, { color: currentColors.text }]}
              placeholder="01/01/2025"
              placeholderTextColor={currentColors.textSecondary}
              value={formData.leaseStartDate}
              onChangeText={(value) => updateFormData('leaseStartDate', value)}
            />
          </View>
          {errors.leaseStartDate && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.leaseStartDate}</Text>}
        </View>

        <View style={[styles.inputContainer, { flex: 1 }]}>
          <Text style={[styles.label, { color: currentColors.text }]}>Date de fin</Text>
          <View style={[styles.inputWrapper, { borderColor: errors.leaseEndDate ? currentColors.danger : currentColors.border }]}>
            <Calendar size={20} color={currentColors.textSecondary} />
            <TextInput
              style={[styles.inputWithIcon, { color: currentColors.text }]}
              placeholder="31/12/2025"
              placeholderTextColor={currentColors.textSecondary}
              value={formData.leaseEndDate}
              onChangeText={(value) => updateFormData('leaseEndDate', value)}
            />
          </View>
          {errors.leaseEndDate && <Text style={[styles.errorText, { color: currentColors.danger }]}>{errors.leaseEndDate}</Text>}
        </View>
      </View>

      <View style={[styles.infoCard, { backgroundColor: currentColors.primary + '10', borderColor: currentColors.primary }]}>
        <Text style={[styles.infoTitle, { color: currentColors.primary }]}>
          Invitation automatique
        </Text>
        <Text style={[styles.infoText, { color: currentColors.text }]}>
          Le locataire recevra automatiquement une invitation par email pour rejoindre MonToit+ et commencer à payer ses loyers en ligne via Stripe.
        </Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color={currentColors.text} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: currentColors.text }]}>
          Ajouter une propriété
        </Text>
        <View style={{ width: 44 }} />
      </View>

      {renderStepIndicator()}

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {currentStep === 1 && renderStep1()}
        {currentStep === 2 && renderStep2()}
        {currentStep === 3 && renderStep3()}
        {currentStep === 4 && renderStep4()}
        {currentStep === 5 && renderStep5()}
      </ScrollView>

      <View style={[styles.footer, { borderTopColor: currentColors.border }]}>
        <View style={styles.footerButtons}>
          {currentStep > 1 && (
            <TouchableOpacity
              style={[styles.secondaryButton, { borderColor: currentColors.border }]}
              onPress={handlePrevious}
            >
              <Text style={[styles.secondaryButtonText, { color: currentColors.text }]}>
                Précédent
              </Text>
            </TouchableOpacity>
          )}

          <TouchableOpacity
            style={[
              styles.primaryButton,
              { 
                backgroundColor: currentColors.primary,
                flex: currentStep === 1 ? 1 : 0.6,
              }
            ]}
            onPress={currentStep === 5 ? handleSubmit : handleNext}
            disabled={isLoading}
          >
            {isLoading ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <Text style={styles.primaryButtonText}>
                {currentStep === 5 ? 'Créer la propriété' : 'Suivant'}
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  backButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
  },
  stepIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  stepContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepNumber: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
  stepLine: {
    width: 40,
    height: 2,
    marginHorizontal: 8,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  stepContent: {
    paddingBottom: 40,
  },
  stepTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    marginBottom: 24,
    textAlign: 'center',
  },
  inputContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  inputWithIcon: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    marginLeft: 12,
  },
  textArea: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    height: 100,
    textAlignVertical: 'top',
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  typeSelector: {
    gap: 12,
  },
  typeOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
  },
  typeEmoji: {
    fontSize: 20,
    marginRight: 12,
  },
  typeOptionText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
  },
  amenitiesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  amenityChip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
  },
  amenityText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
  },
  summaryCard: {
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    marginTop: 20,
  },
  summaryTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 16,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  summaryTotal: {
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
    paddingTop: 12,
    marginTop: 8,
  },
  summaryLabel: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
  },
  summaryValue: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  photosSection: {
    gap: 20,
  },
  addPhotoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderStyle: 'dashed',
    gap: 8,
  },
  addPhotoText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
  },
  photosGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  photoContainer: {
    position: 'relative',
    width: 100,
    height: 100,
  },
  photo: {
    width: 100,
    height: 100,
    borderRadius: 12,
  },
  removePhotoButton: {
    position: 'absolute',
    top: -8,
    right: -8,
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  noPhotosText: {
    textAlign: 'center',
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    fontStyle: 'italic',
  },
  infoCard: {
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    marginTop: 20,
  },
  infoTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    lineHeight: 20,
  },
  errorText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    marginTop: 4,
  },
  footer: {
    borderTopWidth: 1,
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  footerButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  primaryButton: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primaryButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  secondaryButton: {
    flex: 0.4,
    paddingVertical: 16,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  secondaryButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
});