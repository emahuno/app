import { Tabs, Redirect } from 'expo-router';
import { useColorScheme } from 'react-native';
import { Chrome as Home, FileText, CreditCard, Folder, User, Plus } from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';

export default function TabLayout() {
  const colorScheme = useColorScheme();
  const { user } = useAuth();
  
  if (!user) {
    return <Redirect href="/(auth)/login" />;
  }

  const colors = {
    light: {
      primary: '#2563EB',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  // Masquer l'onglet contrats pour les propriétaires qui habitent leur maison
  const showContracts = user.role !== 'owner';
  const showAddProperty = user.role === 'landlord';

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: currentColors.background,
          borderTopColor: currentColors.border,
          height: 90,
          paddingBottom: 20,
          paddingTop: 8,
        },
        tabBarLabelStyle: {
          fontFamily: 'Inter-Medium',
          fontSize: 12,
          marginTop: 4,
        },
        tabBarActiveTintColor: currentColors.primary,
        tabBarInactiveTintColor: currentColors.textSecondary,
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Accueil',
          tabBarIcon: ({ size, color }) => (
            <Home size={size} color={color} />
          ),
        }}
      />
      {showContracts && (
        <Tabs.Screen
          name="contrats"
          options={{
            title: 'Contrats',
            tabBarIcon: ({ size, color }) => (
              <FileText size={size} color={color} />
            ),
          }}
        />
      )}
      {showAddProperty && (
        <Tabs.Screen
          name="add-property"
          options={{
            title: 'Ajouter',
            tabBarIcon: ({ size, color }) => (
              <Plus size={size} color={color} />
            ),
          }}
        />
      )}
      <Tabs.Screen
        name="paiements"
        options={{
          title: 'Paiements',
          tabBarIcon: ({ size, color }) => (
            <CreditCard size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="documents"
        options={{
          title: 'Documents',
          tabBarIcon: ({ size, color }) => (
            <Folder size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="profil"
        options={{
          title: 'Profil',
          tabBarIcon: ({ size, color }) => (
            <User size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="edit-profile"
        options={{
          href: null, // Cache cet onglet de la navigation
        }}
      />
      <Tabs.Screen
        name="payment-methods"
        options={{
          href: null, // Cache cet onglet de la navigation
        }}
      />
      <Tabs.Screen
        name="messages"
        options={{
          href: null, // Cache cet onglet de la navigation
        }}
      />
    </Tabs>
  );
}