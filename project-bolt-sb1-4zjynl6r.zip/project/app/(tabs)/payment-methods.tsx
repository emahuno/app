import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  useColorScheme,
  SafeAreaView,
  ScrollView,
  Alert,
  Modal,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { ArrowLeft, CreditCard, Plus, Trash2, CreditCard as Edit3, Shield } from 'lucide-react-native';

interface PaymentMethod {
  id: string;
  type: 'card' | 'paypal';
  last4?: string;
  brand?: string;
  email?: string;
  isDefault: boolean;
}

export default function PaymentMethodsScreen() {
  const colorScheme = useColorScheme();
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([
    {
      id: '1',
      type: 'card',
      last4: '4242',
      brand: 'Visa',
      isDefault: true,
    },
    {
      id: '2',
      type: 'paypal',
      email: 'marie.dubois@email.com',
      isDefault: false,
    },
  ]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedType, setSelectedType] = useState<'card' | 'paypal'>('card');
  const [isLoading, setIsLoading] = useState(false);
  const [cardForm, setCardForm] = useState({
    number: '',
    expiry: '',
    cvc: '',
    name: '',
  });

  const colors = {
    light: {
      primary: '#2563EB',
      success: '#10B981',
      warning: '#F59E0B',
      danger: '#EF4444',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      success: '#34D399',
      warning: '#FBBF24',
      danger: '#F87171',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  const handleDeletePaymentMethod = (id: string) => {
    Alert.alert(
      'Supprimer le moyen de paiement',
      'Êtes-vous sûr de vouloir supprimer ce moyen de paiement ?',
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: () => {
            setPaymentMethods(prev => prev.filter(method => method.id !== id));
          },
        },
      ]
    );
  };

  const handleSetDefault = (id: string) => {
    setPaymentMethods(prev =>
      prev.map(method => ({
        ...method,
        isDefault: method.id === id,
      }))
    );
  };

  const handleAddPaymentMethod = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const newMethod: PaymentMethod = {
        id: Date.now().toString(),
        type: selectedType,
        ...(selectedType === 'card' 
          ? { last4: cardForm.number.slice(-4), brand: 'Visa' }
          : { email: 'nouveau@email.com' }
        ),
        isDefault: paymentMethods.length === 0,
      };

      setPaymentMethods(prev => [...prev, newMethod]);
      setShowAddModal(false);
      setCardForm({ number: '', expiry: '', cvc: '', name: '' });
      Alert.alert('Succès', 'Moyen de paiement ajouté avec succès');
    } catch (error) {
      Alert.alert('Erreur', 'Une erreur est survenue');
    } finally {
      setIsLoading(false);
    }
  };

  const PaymentMethodCard = ({ method }: { method: PaymentMethod }) => (
    <View style={[styles.methodCard, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
      <View style={styles.methodHeader}>
        <View style={styles.methodInfo}>
          <View style={[styles.methodIcon, { backgroundColor: currentColors.primary + '20' }]}>
            <CreditCard size={20} color={currentColors.primary} />
          </View>
          <View style={styles.methodDetails}>
            <Text style={[styles.methodTitle, { color: currentColors.text }]}>
              {method.type === 'card' 
                ? `${method.brand} •••• ${method.last4}`
                : `PayPal - ${method.email}`
              }
            </Text>
            {method.isDefault && (
              <Text style={[styles.defaultBadge, { color: currentColors.success }]}>
                Par défaut
              </Text>
            )}
          </View>
        </View>
        
        <View style={styles.methodActions}>
          {!method.isDefault && (
            <TouchableOpacity
              style={[styles.actionButton, { backgroundColor: currentColors.success + '20' }]}
              onPress={() => handleSetDefault(method.id)}
            >
              <Shield size={16} color={currentColors.success} />
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: currentColors.danger + '20' }]}
            onPress={() => handleDeletePaymentMethod(method.id)}
          >
            <Trash2 size={16} color={currentColors.danger} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color={currentColors.text} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: currentColors.text }]}>
          Moyens de paiement
        </Text>
        <TouchableOpacity
          style={[styles.addButton, { backgroundColor: currentColors.primary }]}
          onPress={() => setShowAddModal(true)}
        >
          <Plus size={20} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: currentColors.text }]}>
            Cartes et comptes
          </Text>
          <Text style={[styles.sectionSubtitle, { color: currentColors.textSecondary }]}>
            Gérez vos moyens de paiement pour les transactions
          </Text>
        </View>

        <View style={styles.methodsList}>
          {paymentMethods.map((method) => (
            <PaymentMethodCard key={method.id} method={method} />
          ))}
        </View>

        {paymentMethods.length === 0 && (
          <View style={styles.emptyState}>
            <CreditCard size={48} color={currentColors.textSecondary} />
            <Text style={[styles.emptyTitle, { color: currentColors.text }]}>
              Aucun moyen de paiement
            </Text>
            <Text style={[styles.emptySubtitle, { color: currentColors.textSecondary }]}>
              Ajoutez une carte ou un compte PayPal pour effectuer des paiements
            </Text>
          </View>
        )}
      </ScrollView>

      <Modal
        visible={showAddModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowAddModal(false)}
      >
        <SafeAreaView style={[styles.modalContainer, { backgroundColor: currentColors.background }]}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setShowAddModal(false)}>
              <Text style={[styles.modalCancel, { color: currentColors.textSecondary }]}>
                Annuler
              </Text>
            </TouchableOpacity>
            <Text style={[styles.modalTitle, { color: currentColors.text }]}>
              Ajouter un moyen de paiement
            </Text>
            <TouchableOpacity
              onPress={handleAddPaymentMethod}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator size="small\" color={currentColors.primary} />
              ) : (
                <Text style={[styles.modalSave, { color: currentColors.primary }]}>
                  Ajouter
                </Text>
              )}
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            <View style={styles.typeSelector}>
              <TouchableOpacity
                style={[
                  styles.typeOption,
                  {
                    backgroundColor: selectedType === 'card' ? currentColors.primary + '20' : currentColors.card,
                    borderColor: selectedType === 'card' ? currentColors.primary : currentColors.border,
                  }
                ]}
                onPress={() => setSelectedType('card')}
              >
                <CreditCard size={20} color={selectedType === 'card' ? currentColors.primary : currentColors.textSecondary} />
                <Text style={[
                  styles.typeOptionText,
                  { color: selectedType === 'card' ? currentColors.primary : currentColors.text }
                ]}>
                  Carte bancaire
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.typeOption,
                  {
                    backgroundColor: selectedType === 'paypal' ? currentColors.primary + '20' : currentColors.card,
                    borderColor: selectedType === 'paypal' ? currentColors.primary : currentColors.border,
                  }
                ]}
                onPress={() => setSelectedType('paypal')}
              >
                <Text style={[
                  styles.paypalIcon,
                  { color: selectedType === 'paypal' ? currentColors.primary : currentColors.textSecondary }
                ]}>
                  PP
                </Text>
                <Text style={[
                  styles.typeOptionText,
                  { color: selectedType === 'paypal' ? currentColors.primary : currentColors.text }
                ]}>
                  PayPal
                </Text>
              </TouchableOpacity>
            </View>

            {selectedType === 'card' && (
              <View style={styles.cardForm}>
                <View style={styles.inputContainer}>
                  <Text style={[styles.label, { color: currentColors.text }]}>Numéro de carte</Text>
                  <TextInput
                    style={[styles.input, { color: currentColors.text, borderColor: currentColors.border }]}
                    placeholder="1234 5678 9012 3456"
                    placeholderTextColor={currentColors.textSecondary}
                    value={cardForm.number}
                    onChangeText={(text) => setCardForm(prev => ({ ...prev, number: text }))}
                    keyboardType="numeric"
                    maxLength={19}
                  />
                </View>

                <View style={styles.row}>
                  <View style={[styles.inputContainer, { flex: 1 }]}>
                    <Text style={[styles.label, { color: currentColors.text }]}>Expiration</Text>
                    <TextInput
                      style={[styles.input, { color: currentColors.text, borderColor: currentColors.border }]}
                      placeholder="MM/AA"
                      placeholderTextColor={currentColors.textSecondary}
                      value={cardForm.expiry}
                      onChangeText={(text) => setCardForm(prev => ({ ...prev, expiry: text }))}
                      keyboardType="numeric"
                      maxLength={5}
                    />
                  </View>

                  <View style={[styles.inputContainer, { flex: 1 }]}>
                    <Text style={[styles.label, { color: currentColors.text }]}>CVC</Text>
                    <TextInput
                      style={[styles.input, { color: currentColors.text, borderColor: currentColors.border }]}
                      placeholder="123"
                      placeholderTextColor={currentColors.textSecondary}
                      value={cardForm.cvc}
                      onChangeText={(text) => setCardForm(prev => ({ ...prev, cvc: text }))}
                      keyboardType="numeric"
                      maxLength={4}
                      secureTextEntry
                    />
                  </View>
                </View>

                <View style={styles.inputContainer}>
                  <Text style={[styles.label, { color: currentColors.text }]}>Nom sur la carte</Text>
                  <TextInput
                    style={[styles.input, { color: currentColors.text, borderColor: currentColors.border }]}
                    placeholder="Marie Dubois"
                    placeholderTextColor={currentColors.textSecondary}
                    value={cardForm.name}
                    onChangeText={(text) => setCardForm(prev => ({ ...prev, name: text }))}
                    autoComplete="name"
                  />
                </View>
              </View>
            )}

            {selectedType === 'paypal' && (
              <View style={styles.paypalInfo}>
                <Text style={[styles.paypalText, { color: currentColors.textSecondary }]}>
                  Vous serez redirigé vers PayPal pour autoriser les paiements depuis votre compte.
                </Text>
              </View>
            )}
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  backButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    flex: 1,
    textAlign: 'center',
  },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  sectionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    lineHeight: 20,
  },
  methodsList: {
    gap: 12,
  },
  methodCard: {
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
  },
  methodHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  methodInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  methodIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  methodDetails: {
    flex: 1,
  },
  methodTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    marginBottom: 2,
  },
  defaultBadge: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
  },
  methodActions: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    lineHeight: 24,
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  modalCancel: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
  },
  modalTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
  },
  modalSave: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  modalContent: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 24,
  },
  typeSelector: {
    gap: 12,
    marginBottom: 32,
  },
  typeOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    gap: 12,
  },
  typeOptionText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
  },
  paypalIcon: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    width: 20,
    textAlign: 'center',
  },
  cardForm: {
    gap: 20,
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  inputContainer: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
  },
  paypalInfo: {
    padding: 20,
    borderRadius: 12,
    backgroundColor: '#F8FAFC',
  },
  paypalText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    lineHeight: 20,
    textAlign: 'center',
  },
});