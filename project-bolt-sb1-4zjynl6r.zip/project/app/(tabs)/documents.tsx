import React, { useState } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  StyleSheet, 
  useColorScheme,
  SafeAreaView,
  TouchableOpacity,
  Alert
} from 'react-native';
import { useAuth } from '@/contexts/AuthContext';
import { FileText, Image, File, Download, Eye, Share, Plus, Search, Filter, Calendar, Folder, Upload, Chrome as Home, Receipt, FileCheck, MapPin } from 'lucide-react-native';

interface Document {
  id: string;
  name: string;
  type: 'contract' | 'receipt' | 'invoice' | 'insurance' | 'deed' | 'payment' | 'tax' | 'plan' | 'other';
  fileType: 'pdf' | 'image' | 'doc';
  size: string;
  date: string;
  property?: string;
}

export default function DocumentsScreen() {
  const colorScheme = useColorScheme();
  const { user } = useAuth();
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const colors = {
    light: {
      primary: '#2563EB',
      success: '#10B981',
      warning: '#F59E0B',
      danger: '#EF4444',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      success: '#34D399',
      warning: '#FBBF24',
      danger: '#F87171',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  // Catégories selon le rôle utilisateur
  const getCategories = () => {
    const baseCategories = [
      { id: 'all', name: 'Tous', count: 8 },
    ];

    if (user?.role === 'owner') {
      return [
        ...baseCategories,
        { id: 'deed', name: 'Actes', count: 1 },
        { id: 'payment', name: 'Paiements', count: 2 },
        { id: 'tax', name: 'Taxes', count: 1 },
        { id: 'plan', name: 'Plans', count: 1 },
        { id: 'insurance', name: 'Assurance', count: 1 },
        { id: 'other', name: 'Autres', count: 2 },
      ];
    } else {
      return [
        ...baseCategories,
        { id: 'contract', name: 'Contrats', count: 3 },
        { id: 'receipt', name: 'Reçus', count: 2 },
        { id: 'invoice', name: 'Factures', count: 2 },
        { id: 'insurance', name: 'Assurance', count: 1 },
      ];
    }
  };

  // Documents selon le rôle utilisateur
  const getDocuments = (): Document[] => {
    if (user?.role === 'owner') {
      return [
        {
          id: '1',
          name: 'Acte de vente - 28 rue des Chênes',
          type: 'deed',
          fileType: 'pdf',
          size: '3.2 MB',
          date: '2022-03-01',
        },
        {
          id: '2',
          name: 'Justificatif paiement hypothèque - Décembre',
          type: 'payment',
          fileType: 'pdf',
          size: '0.8 MB',
          date: '2024-12-15',
        },
        {
          id: '3',
          name: 'Avis de taxe foncière 2024',
          type: 'tax',
          fileType: 'pdf',
          size: '1.1 MB',
          date: '2024-10-15',
        },
        {
          id: '4',
          name: 'Plan du logement',
          type: 'plan',
          fileType: 'pdf',
          size: '2.5 MB',
          date: '2022-03-01',
        },
        {
          id: '5',
          name: 'Attestation assurance habitation',
          type: 'insurance',
          fileType: 'pdf',
          size: '1.1 MB',
          date: '2024-01-08',
        },
        {
          id: '6',
          name: 'Facture travaux cuisine',
          type: 'other',
          fileType: 'pdf',
          size: '1.8 MB',
          date: '2024-09-20',
        },
      ];
    } else {
      return [
        {
          id: '1',
          name: 'Contrat de location - Janvier 2024',
          type: 'contract',
          fileType: 'pdf',
          size: '2.4 MB',
          date: '2024-01-15',
          property: '12 rue de la République',
        },
        {
          id: '2',
          name: 'Reçu de loyer - Décembre 2024',
          type: 'receipt',
          fileType: 'pdf',
          size: '0.8 MB',
          date: '2024-12-05',
          property: '12 rue de la République',
        },
        {
          id: '3',
          name: 'État des lieux d\'entrée',
          type: 'other',
          fileType: 'pdf',
          size: '5.2 MB',
          date: '2024-01-10',
          property: '12 rue de la République',
        },
        {
          id: '4',
          name: 'Attestation assurance habitation',
          type: 'insurance',
          fileType: 'pdf',
          size: '1.1 MB',
          date: '2024-01-08',
        },
        {
          id: '5',
          name: 'Facture électricité - Novembre',
          type: 'invoice',
          fileType: 'pdf',
          size: '0.6 MB',
          date: '2024-11-28',
        },
        {
          id: '6',
          name: 'Photo compteur électrique',
          type: 'other',
          fileType: 'image',
          size: '2.8 MB',
          date: '2024-11-15',
        },
      ];
    }
  };

  const categories = getCategories();
  const documents = getDocuments();

  const getFileIcon = (fileType: string) => {
    switch (fileType) {
      case 'image':
        return Image;
      case 'pdf':
        return FileText;
      default:
        return File;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'contract':
        return currentColors.primary;
      case 'receipt':
        return currentColors.success;
      case 'invoice':
        return currentColors.warning;
      case 'insurance':
        return currentColors.danger;
      case 'deed':
        return currentColors.primary;
      case 'payment':
        return currentColors.success;
      case 'tax':
        return currentColors.warning;
      case 'plan':
        return currentColors.primary;
      default:
        return currentColors.textSecondary;
    }
  };

  const getTypeName = (type: string) => {
    switch (type) {
      case 'contract':
        return 'Contrat';
      case 'receipt':
        return 'Reçu';
      case 'invoice':
        return 'Facture';
      case 'insurance':
        return 'Assurance';
      case 'deed':
        return 'Acte';
      case 'payment':
        return 'Paiement';
      case 'tax':
        return 'Taxe';
      case 'plan':
        return 'Plan';
      default:
        return 'Autre';
    }
  };

  const filteredDocuments = activeCategory === 'all' 
    ? documents 
    : documents.filter(doc => doc.type === activeCategory);

  const handleDocumentAction = (action: string, documentId: string) => {
    Alert.alert('Action', `${action} pour le document ${documentId}`);
  };

  const DocumentCard = ({ document }: { document: Document }) => {
    const FileIcon = getFileIcon(document.fileType);
    
    return (
      <View style={[styles.documentCard, { 
        backgroundColor: currentColors.card,
        borderColor: currentColors.border,
      }]}>
        <View style={styles.documentHeader}>
          <View style={[styles.fileIconContainer, { backgroundColor: getTypeColor(document.type) + '20' }]}>
            <FileIcon size={20} color={getTypeColor(document.type)} />
          </View>
          
          <View style={styles.documentInfo}>
            <Text style={[styles.documentName, { color: currentColors.text }]} numberOfLines={2}>
              {document.name}
            </Text>
            <View style={styles.documentMeta}>
              <Text style={[styles.metaText, { color: currentColors.textSecondary }]}>
                {getTypeName(document.type)} • {document.size}
              </Text>
              <View style={styles.metaRow}>
                <Calendar size={12} color={currentColors.textSecondary} />
                <Text style={[styles.metaText, { color: currentColors.textSecondary }]}>
                  {new Date(document.date).toLocaleDateString('fr-FR')}
                </Text>
              </View>
            </View>
            {document.property && (
              <Text style={[styles.propertyText, { color: currentColors.textSecondary }]} numberOfLines={1}>
                {document.property}
              </Text>
            )}
          </View>
        </View>

        <View style={styles.documentActions}>
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: currentColors.primary + '20' }]}
            onPress={() => handleDocumentAction('Consulter', document.id)}
          >
            <Eye size={16} color={currentColors.primary} />
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: currentColors.success + '20' }]}
            onPress={() => handleDocumentAction('Télécharger', document.id)}
          >
            <Download size={16} color={currentColors.success} />
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: currentColors.warning + '20' }]}
            onPress={() => handleDocumentAction('Partager', document.id)}
          >
            <Share size={16} color={currentColors.warning} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: currentColors.text }]}>
          Documents
        </Text>
        <View style={styles.headerActions}>
          <TouchableOpacity
            style={[styles.headerButton, { backgroundColor: currentColors.card }]}
            onPress={() => Alert.alert('Recherche', 'Fonctionnalité bientôt disponible')}
          >
            <Search size={20} color={currentColors.textSecondary} />
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.headerButton, { backgroundColor: currentColors.primary }]}
            onPress={() => Alert.alert('Nouveau document', 'Fonctionnalité bientôt disponible')}
          >
            <Upload size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        horizontal
        style={styles.categoriesContainer}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.categoriesContent}
      >
        {categories.map((category) => (
          <TouchableOpacity
            key={category.id}
            style={[
              styles.categoryChip,
              {
                backgroundColor: activeCategory === category.id 
                  ? currentColors.primary 
                  : currentColors.card,
                borderColor: currentColors.border,
              }
            ]}
            onPress={() => setActiveCategory(category.id)}
          >
            <Text style={[
              styles.categoryText,
              { 
                color: activeCategory === category.id 
                  ? '#FFFFFF' 
                  : currentColors.text 
              }
            ]}>
              {category.name} ({category.count})
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView 
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.documentsGrid}>
          {filteredDocuments.map((document) => (
            <DocumentCard key={document.id} document={document} />
          ))}
        </View>

        {filteredDocuments.length === 0 && (
          <View style={styles.emptyState}>
            <Folder size={48} color={currentColors.textSecondary} />
            <Text style={[styles.emptyTitle, { color: currentColors.text }]}>
              Aucun document
            </Text>
            <Text style={[styles.emptySubtitle, { color: currentColors.textSecondary }]}>
              Aucun document dans cette catégorie
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  headerButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoriesContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  categoriesContent: {
    gap: 8,
  },
  categoryChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
  },
  categoryText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  documentsGrid: {
    gap: 16,
  },
  documentCard: {
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  documentHeader: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  fileIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  documentInfo: {
    flex: 1,
  },
  documentName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 8,
    lineHeight: 22,
  },
  documentMeta: {
    gap: 4,
  },
  metaText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  propertyText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    marginTop: 4,
    fontStyle: 'italic',
  },
  documentActions: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
  },
});