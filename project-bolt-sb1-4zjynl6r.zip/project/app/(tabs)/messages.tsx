import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  useColorScheme,
  SafeAreaView,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Send, User, Phone, Mail } from 'lucide-react-native';

interface Message {
  id: string;
  text: string;
  sender: 'tenant' | 'landlord';
  timestamp: Date;
}

export default function MessagesScreen() {
  const colorScheme = useColorScheme();
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Bonjour, j\'ai remarqué un problème avec le chauffage dans l\'appartement. Pourriez-vous envoyer quelqu\'un pour vérifier ?',
      sender: 'tenant',
      timestamp: new Date('2024-12-20T10:30:00'),
    },
    {
      id: '2',
      text: 'Bonjour Marie, merci de m\'avoir signalé ce problème. Je vais contacter un technicien et vous tiendrai informée.',
      sender: 'landlord',
      timestamp: new Date('2024-12-20T11:15:00'),
    },
    {
      id: '3',
      text: 'Parfait, merci beaucoup pour votre réactivité !',
      sender: 'tenant',
      timestamp: new Date('2024-12-20T11:20:00'),
    },
  ]);
  const [newMessage, setNewMessage] = useState('');

  const colors = {
    light: {
      primary: '#2563EB',
      success: '#10B981',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      success: '#34D399',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  // Informations du propriétaire (simulées)
  const landlordInfo = {
    name: 'Jean Dupont',
    phone: '06 98 76 54 32',
    email: 'jean.dupont@email.com',
  };

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const message: Message = {
      id: Date.now().toString(),
      text: newMessage.trim(),
      sender: 'tenant',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, message]);
    setNewMessage('');

    // Simulation d'une réponse automatique
    setTimeout(() => {
      const autoReply: Message = {
        id: (Date.now() + 1).toString(),
        text: 'Merci pour votre message. Je vous répondrai dans les plus brefs délais.',
        sender: 'landlord',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, autoReply]);
    }, 2000);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('fr-FR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const MessageBubble = ({ message }: { message: Message }) => {
    const isFromUser = message.sender === 'tenant';
    
    return (
      <View style={[
        styles.messageBubble,
        isFromUser ? styles.userMessage : styles.otherMessage,
        {
          backgroundColor: isFromUser ? currentColors.primary : currentColors.card,
          alignSelf: isFromUser ? 'flex-end' : 'flex-start',
        }
      ]}>
        <Text style={[
          styles.messageText,
          { color: isFromUser ? '#FFFFFF' : currentColors.text }
        ]}>
          {message.text}
        </Text>
        <Text style={[
          styles.messageTime,
          { color: isFromUser ? '#FFFFFF' : currentColors.textSecondary, opacity: 0.7 }
        ]}>
          {formatTime(message.timestamp)}
        </Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color={currentColors.text} />
        </TouchableOpacity>
        <View style={styles.headerInfo}>
          <Text style={[styles.headerTitle, { color: currentColors.text }]}>
            {landlordInfo.name}
          </Text>
          <Text style={[styles.headerSubtitle, { color: currentColors.textSecondary }]}>
            Propriétaire
          </Text>
        </View>
        <TouchableOpacity
          style={[styles.contactButton, { backgroundColor: currentColors.primary + '20' }]}
          onPress={() => Alert.alert('Contact', `Appeler ${landlordInfo.phone}`)}
        >
          <Phone size={20} color={currentColors.primary} />
        </TouchableOpacity>
      </View>

      {/* Informations de contact */}
      <View style={[styles.contactInfo, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
        <View style={styles.contactRow}>
          <Phone size={16} color={currentColors.textSecondary} />
          <Text style={[styles.contactText, { color: currentColors.textSecondary }]}>
            {landlordInfo.phone}
          </Text>
        </View>
        <View style={styles.contactRow}>
          <Mail size={16} color={currentColors.textSecondary} />
          <Text style={[styles.contactText, { color: currentColors.textSecondary }]}>
            {landlordInfo.email}
          </Text>
        </View>
      </View>

      <KeyboardAvoidingView 
        style={styles.chatContainer}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView 
          style={styles.messagesContainer}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.messagesContent}
        >
          {messages.map((message) => (
            <MessageBubble key={message.id} message={message} />
          ))}
        </ScrollView>

        <View style={[styles.inputContainer, { borderTopColor: currentColors.border }]}>
          <TextInput
            style={[
              styles.messageInput,
              { 
                backgroundColor: currentColors.card,
                borderColor: currentColors.border,
                color: currentColors.text,
              }
            ]}
            placeholder="Tapez votre message..."
            placeholderTextColor={currentColors.textSecondary}
            value={newMessage}
            onChangeText={setNewMessage}
            multiline
            maxLength={500}
          />
          <TouchableOpacity
            style={[
              styles.sendButton,
              { 
                backgroundColor: newMessage.trim() ? currentColors.primary : currentColors.border,
              }
            ]}
            onPress={handleSendMessage}
            disabled={!newMessage.trim()}
          >
            <Send size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  backButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  headerInfo: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
  },
  headerSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  contactButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  contactInfo: {
    marginHorizontal: 20,
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 16,
    gap: 8,
  },
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  contactText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  chatContainer: {
    flex: 1,
  },
  messagesContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  messagesContent: {
    paddingVertical: 16,
    gap: 12,
  },
  messageBubble: {
    maxWidth: '80%',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 16,
    gap: 4,
  },
  userMessage: {
    borderBottomRightRadius: 4,
  },
  otherMessage: {
    borderBottomLeftRadius: 4,
  },
  messageText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    lineHeight: 22,
  },
  messageTime: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderTopWidth: 1,
    gap: 12,
  },
  messageInput: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    maxHeight: 100,
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
});