import React from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  StyleSheet, 
  useColorScheme,
  SafeAreaView,
  TouchableOpacity,
  Alert
} from 'react-native';
import { FileText, Download, Eye, CreditCard as Edit3, Plus, Calendar, MapPin, User } from 'lucide-react-native';

interface Contract {
  id: string;
  title: string;
  property: string;
  tenant?: string;
  startDate: string;
  endDate: string;
  monthlyRent: string;
  status: 'active' | 'pending' | 'expired';
  type: 'rental' | 'mortgage';
}

export default function ContractsScreen() {
  const colorScheme = useColorScheme();

  const colors = {
    light: {
      primary: '#2563EB',
      success: '#10B981',
      warning: '#F59E0B',
      danger: '#EF4444',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
    },
    dark: {
      primary: '#3B82F6',
      success: '#34D399',
      warning: '#FBBF24',
      danger: '#F87171',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  // Données d'exemple
  const contracts: Contract[] = [
    {
      id: '1',
      title: 'Contrat de location',
      property: '12 rue de la République, Paris 11e',
      tenant: 'Marie Dubois',
      startDate: '2024-01-15',
      endDate: '2025-01-14',
      monthlyRent: '850 €',
      status: 'active',
      type: 'rental',
    },
    {
      id: '2',
      title: 'Contrat de location',
      property: '45 avenue Victor Hugo, Lyon 3e',
      tenant: 'Pierre Martin',
      startDate: '2023-09-01',
      endDate: '2024-08-31',
      monthlyRent: '720 €',
      status: 'expired',
      type: 'rental',
    },
    {
      id: '3',
      title: 'Contrat hypothécaire',
      property: '28 rue des Chênes, Marseille 6e',
      startDate: '2022-03-01',
      endDate: '2042-03-01',
      monthlyRent: '1 200 €',
      status: 'active',
      type: 'mortgage',
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return currentColors.success;
      case 'pending':
        return currentColors.warning;
      case 'expired':
        return currentColors.danger;
      default:
        return currentColors.textSecondary;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active':
        return 'Actif';
      case 'pending':
        return 'En attente';
      case 'expired':
        return 'Expiré';
      default:
        return 'Inconnu';
    }
  };

  const handleContractAction = (action: string, contractId: string) => {
    Alert.alert('Action', `${action} pour le contrat ${contractId}`);
  };

  const ContractCard = ({ contract }: { contract: Contract }) => (
    <View style={[styles.contractCard, { 
      backgroundColor: currentColors.card,
      borderColor: currentColors.border,
    }]}>
      <View style={styles.contractHeader}>
        <View style={styles.contractInfo}>
          <Text style={[styles.contractTitle, { color: currentColors.text }]}>
            {contract.title}
          </Text>
          <View style={[styles.statusBadge, { backgroundColor: getStatusColor(contract.status) + '20' }]}>
            <Text style={[styles.statusText, { color: getStatusColor(contract.status) }]}>
              {getStatusText(contract.status)}
            </Text>
          </View>
        </View>
        <View style={[styles.iconContainer, { backgroundColor: currentColors.primary + '20' }]}>
          <FileText size={20} color={currentColors.primary} />
        </View>
      </View>

      <View style={styles.contractDetails}>
        <View style={styles.detailRow}>
          <MapPin size={16} color={currentColors.textSecondary} />
          <Text style={[styles.detailText, { color: currentColors.textSecondary }]}>
            {contract.property}
          </Text>
        </View>

        {contract.tenant && (
          <View style={styles.detailRow}>
            <User size={16} color={currentColors.textSecondary} />
            <Text style={[styles.detailText, { color: currentColors.textSecondary }]}>
              {contract.tenant}
            </Text>
          </View>
        )}

        <View style={styles.detailRow}>
          <Calendar size={16} color={currentColors.textSecondary} />
          <Text style={[styles.detailText, { color: currentColors.textSecondary }]}>
            Du {new Date(contract.startDate).toLocaleDateString('fr-FR')} au {new Date(contract.endDate).toLocaleDateString('fr-FR')}
          </Text>
        </View>

        <Text style={[styles.rentAmount, { color: currentColors.text }]}>
          {contract.monthlyRent}/mois
        </Text>
      </View>

      <View style={styles.contractActions}>
        <TouchableOpacity
          style={[styles.actionButton, { backgroundColor: currentColors.primary + '20' }]}
          onPress={() => handleContractAction('Consulter', contract.id)}
        >
          <Eye size={16} color={currentColors.primary} />
          <Text style={[styles.actionText, { color: currentColors.primary }]}>
            Consulter
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionButton, { backgroundColor: currentColors.success + '20' }]}
          onPress={() => handleContractAction('Télécharger', contract.id)}
        >
          <Download size={16} color={currentColors.success} />
          <Text style={[styles.actionText, { color: currentColors.success }]}>
            Télécharger
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionButton, { backgroundColor: currentColors.warning + '20' }]}
          onPress={() => handleContractAction('Modifier', contract.id)}
        >
          <Edit3 size={16} color={currentColors.warning} />
          <Text style={[styles.actionText, { color: currentColors.warning }]}>
            Modifier
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: currentColors.text }]}>
          Mes contrats
        </Text>
        <TouchableOpacity
          style={[styles.addButton, { backgroundColor: currentColors.primary }]}
          onPress={() => Alert.alert('Nouveau contrat', 'Fonctionnalité bientôt disponible')}
        >
          <Plus size={20} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      <ScrollView 
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
      >
        {contracts.map((contract) => (
          <ContractCard key={contract.id} contract={contract} />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
  },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  contractCard: {
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  contractHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  contractInfo: {
    flex: 1,
  },
  contractTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 8,
  },
  statusBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  contractDetails: {
    marginBottom: 20,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    marginLeft: 8,
    flex: 1,
    lineHeight: 20,
  },
  rentAmount: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    marginTop: 8,
  },
  contractActions: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    gap: 6,
  },
  actionText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
  },
});