import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  useColorScheme,
  SafeAreaView,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, User, Mail, Phone, MapPin, Save } from 'lucide-react-native';

export default function EditProfileScreen() {
  const colorScheme = useColorScheme();
  const { user, updateProfile, isLoading } = useAuth();
  const [formData, setFormData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    address: user?.address || '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const colors = {
    light: {
      primary: '#2563EB',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
      error: '#EF4444',
    },
    dark: {
      primary: '#3B82F6',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
      error: '#F87171',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.firstName) newErrors.firstName = 'Le prénom est requis';
    if (!formData.lastName) newErrors.lastName = 'Le nom est requis';
    if (!formData.email) {
      newErrors.email = 'L\'email est requis';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Format d\'email invalide';
    }
    if (!formData.phone) newErrors.phone = 'Le téléphone est requis';
    if (!formData.address) newErrors.address = 'L\'adresse est requise';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) return;

    try {
      await updateProfile(formData);
      Alert.alert('Succès', 'Profil mis à jour avec succès', [
        { text: 'OK', onPress: () => router.back() }
      ]);
    } catch (error) {
      Alert.alert('Erreur', 'Une erreur est survenue lors de la mise à jour');
    }
  };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color={currentColors.text} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: currentColors.text }]}>
          Modifier le profil
        </Text>
        <TouchableOpacity
          style={[styles.saveButton, { backgroundColor: currentColors.primary }]}
          onPress={handleSave}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator size="small\" color="#FFFFFF" />
          ) : (
            <Save size={20} color="#FFFFFF" />
          )}
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.form}>
          <View style={styles.row}>
            <View style={[styles.inputContainer, { flex: 1 }]}>
              <Text style={[styles.label, { color: currentColors.text }]}>Prénom</Text>
              <View style={[styles.inputWrapper, { borderColor: errors.firstName ? currentColors.error : currentColors.border }]}>
                <User size={20} color={currentColors.textSecondary} />
                <TextInput
                  style={[styles.input, { color: currentColors.text }]}
                  placeholder="Prénom"
                  placeholderTextColor={currentColors.textSecondary}
                  value={formData.firstName}
                  onChangeText={(value) => updateFormData('firstName', value)}
                  autoComplete="given-name"
                />
              </View>
              {errors.firstName && (
                <Text style={[styles.errorText, { color: currentColors.error }]}>
                  {errors.firstName}
                </Text>
              )}
            </View>

            <View style={[styles.inputContainer, { flex: 1 }]}>
              <Text style={[styles.label, { color: currentColors.text }]}>Nom</Text>
              <View style={[styles.inputWrapper, { borderColor: errors.lastName ? currentColors.error : currentColors.border }]}>
                <User size={20} color={currentColors.textSecondary} />
                <TextInput
                  style={[styles.input, { color: currentColors.text }]}
                  placeholder="Nom"
                  placeholderTextColor={currentColors.textSecondary}
                  value={formData.lastName}
                  onChangeText={(value) => updateFormData('lastName', value)}
                  autoComplete="family-name"
                />
              </View>
              {errors.lastName && (
                <Text style={[styles.errorText, { color: currentColors.error }]}>
                  {errors.lastName}
                </Text>
              )}
            </View>
          </View>

          <View style={styles.inputContainer}>
            <Text style={[styles.label, { color: currentColors.text }]}>Email</Text>
            <View style={[styles.inputWrapper, { borderColor: errors.email ? currentColors.error : currentColors.border }]}>
              <Mail size={20} color={currentColors.textSecondary} />
              <TextInput
                style={[styles.input, { color: currentColors.text }]}
                placeholder="Adresse email"
                placeholderTextColor={currentColors.textSecondary}
                value={formData.email}
                onChangeText={(value) => updateFormData('email', value)}
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
              />
            </View>
            {errors.email && (
              <Text style={[styles.errorText, { color: currentColors.error }]}>
                {errors.email}
              </Text>
            )}
          </View>

          <View style={styles.inputContainer}>
            <Text style={[styles.label, { color: currentColors.text }]}>Téléphone</Text>
            <View style={[styles.inputWrapper, { borderColor: errors.phone ? currentColors.error : currentColors.border }]}>
              <Phone size={20} color={currentColors.textSecondary} />
              <TextInput
                style={[styles.input, { color: currentColors.text }]}
                placeholder="Numéro de téléphone"
                placeholderTextColor={currentColors.textSecondary}
                value={formData.phone}
                onChangeText={(value) => updateFormData('phone', value)}
                keyboardType="phone-pad"
                autoComplete="tel"
              />
            </View>
            {errors.phone && (
              <Text style={[styles.errorText, { color: currentColors.error }]}>
                {errors.phone}
              </Text>
            )}
          </View>

          <View style={styles.inputContainer}>
            <Text style={[styles.label, { color: currentColors.text }]}>Adresse</Text>
            <View style={[styles.inputWrapper, { borderColor: errors.address ? currentColors.error : currentColors.border }]}>
              <MapPin size={20} color={currentColors.textSecondary} />
              <TextInput
                style={[styles.input, { color: currentColors.text }]}
                placeholder="Adresse complète"
                placeholderTextColor={currentColors.textSecondary}
                value={formData.address}
                onChangeText={(value) => updateFormData('address', value)}
                autoComplete="street-address"
                multiline
                numberOfLines={2}
              />
            </View>
            {errors.address && (
              <Text style={[styles.errorText, { color: currentColors.error }]}>
                {errors.address}
              </Text>
            )}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  backButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    flex: 1,
    textAlign: 'center',
  },
  saveButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  form: {
    gap: 24,
    paddingBottom: 40,
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  inputContainer: {
    gap: 8,
  },
  label: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    marginBottom: 4,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    gap: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
  },
  errorText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    marginLeft: 4,
  },
});