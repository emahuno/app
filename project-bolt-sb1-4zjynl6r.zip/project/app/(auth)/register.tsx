import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  useColorScheme,
  SafeAreaView,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Link } from 'expo-router';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import { Eye, EyeOff, Mail, Lock, User, Phone, MapPin, Building2, Key, Chrome as Home } from 'lucide-react-native';

export default function RegisterScreen() {
  const colorScheme = useColorScheme();
  const { register, isLoading } = useAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    phone: '',
    address: '',
    role: 'tenant' as UserRole,
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const colors = {
    light: {
      primary: '#2563EB',
      background: '#FFFFFF',
      card: '#F8FAFC',
      text: '#1E293B',
      textSecondary: '#64748B',
      border: '#E2E8F0',
      error: '#EF4444',
    },
    dark: {
      primary: '#3B82F6',
      background: '#0F172A',
      card: '#1E293B',
      text: '#F1F5F9',
      textSecondary: '#94A3B8',
      border: '#334155',
      error: '#F87171',
    }
  };

  const currentColors = colorScheme === 'dark' ? colors.dark : colors.light;

  const roles = [
    { id: 'tenant' as UserRole, title: 'Locataire', icon: Key },
    { id: 'landlord' as UserRole, title: 'Propriétaire bailleur', icon: Building2 },
    { id: 'owner' as UserRole, title: 'Propriétaire', icon: Home },
  ];

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.firstName) newErrors.firstName = 'Le prénom est requis';
    if (!formData.lastName) newErrors.lastName = 'Le nom est requis';
    if (!formData.email) {
      newErrors.email = 'L\'email est requis';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Format d\'email invalide';
    }
    if (!formData.password) {
      newErrors.password = 'Le mot de passe est requis';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Le mot de passe doit contenir au moins 6 caractères';
    }
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Les mots de passe ne correspondent pas';
    }
    if (!formData.phone) newErrors.phone = 'Le téléphone est requis';
    if (!formData.address) newErrors.address = 'L\'adresse est requise';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleRegister = async () => {
    if (!validateForm()) return;

    try {
      await register(formData);
    } catch (error) {
      Alert.alert('Erreur', error instanceof Error ? error.message : 'Une erreur est survenue');
    }
  };

  const updateFormData = (field: string, value: string | UserRole) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          <View style={styles.header}>
            <Text style={[styles.title, { color: currentColors.text }]}>
              Créer un compte
            </Text>
            <Text style={[styles.subtitle, { color: currentColors.textSecondary }]}>
              Rejoignez MonToit+ dès aujourd'hui
            </Text>
          </View>

          <View style={styles.form}>
            <View style={styles.row}>
              <View style={[styles.inputContainer, { flex: 1 }]}>
                <View style={[styles.inputWrapper, { borderColor: errors.firstName ? currentColors.error : currentColors.border }]}>
                  <User size={20} color={currentColors.textSecondary} />
                  <TextInput
                    style={[styles.input, { color: currentColors.text }]}
                    placeholder="Prénom"
                    placeholderTextColor={currentColors.textSecondary}
                    value={formData.firstName}
                    onChangeText={(value) => updateFormData('firstName', value)}
                    autoComplete="given-name"
                  />
                </View>
                {errors.firstName && (
                  <Text style={[styles.errorText, { color: currentColors.error }]}>
                    {errors.firstName}
                  </Text>
                )}
              </View>

              <View style={[styles.inputContainer, { flex: 1 }]}>
                <View style={[styles.inputWrapper, { borderColor: errors.lastName ? currentColors.error : currentColors.border }]}>
                  <User size={20} color={currentColors.textSecondary} />
                  <TextInput
                    style={[styles.input, { color: currentColors.text }]}
                    placeholder="Nom"
                    placeholderTextColor={currentColors.textSecondary}
                    value={formData.lastName}
                    onChangeText={(value) => updateFormData('lastName', value)}
                    autoComplete="family-name"
                  />
                </View>
                {errors.lastName && (
                  <Text style={[styles.errorText, { color: currentColors.error }]}>
                    {errors.lastName}
                  </Text>
                )}
              </View>
            </View>

            <View style={styles.inputContainer}>
              <View style={[styles.inputWrapper, { borderColor: errors.email ? currentColors.error : currentColors.border }]}>
                <Mail size={20} color={currentColors.textSecondary} />
                <TextInput
                  style={[styles.input, { color: currentColors.text }]}
                  placeholder="Adresse email"
                  placeholderTextColor={currentColors.textSecondary}
                  value={formData.email}
                  onChangeText={(value) => updateFormData('email', value)}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoComplete="email"
                />
              </View>
              {errors.email && (
                <Text style={[styles.errorText, { color: currentColors.error }]}>
                  {errors.email}
                </Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <View style={[styles.inputWrapper, { borderColor: errors.password ? currentColors.error : currentColors.border }]}>
                <Lock size={20} color={currentColors.textSecondary} />
                <TextInput
                  style={[styles.input, { color: currentColors.text }]}
                  placeholder="Mot de passe"
                  placeholderTextColor={currentColors.textSecondary}
                  value={formData.password}
                  onChangeText={(value) => updateFormData('password', value)}
                  secureTextEntry={!showPassword}
                  autoComplete="new-password"
                />
                <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                  {showPassword ? (
                    <EyeOff size={20} color={currentColors.textSecondary} />
                  ) : (
                    <Eye size={20} color={currentColors.textSecondary} />
                  )}
                </TouchableOpacity>
              </View>
              {errors.password && (
                <Text style={[styles.errorText, { color: currentColors.error }]}>
                  {errors.password}
                </Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <View style={[styles.inputWrapper, { borderColor: errors.confirmPassword ? currentColors.error : currentColors.border }]}>
                <Lock size={20} color={currentColors.textSecondary} />
                <TextInput
                  style={[styles.input, { color: currentColors.text }]}
                  placeholder="Confirmer le mot de passe"
                  placeholderTextColor={currentColors.textSecondary}
                  value={formData.confirmPassword}
                  onChangeText={(value) => updateFormData('confirmPassword', value)}
                  secureTextEntry={!showConfirmPassword}
                  autoComplete="new-password"
                />
                <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)}>
                  {showConfirmPassword ? (
                    <EyeOff size={20} color={currentColors.textSecondary} />
                  ) : (
                    <Eye size={20} color={currentColors.textSecondary} />
                  )}
                </TouchableOpacity>
              </View>
              {errors.confirmPassword && (
                <Text style={[styles.errorText, { color: currentColors.error }]}>
                  {errors.confirmPassword}
                </Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <View style={[styles.inputWrapper, { borderColor: errors.phone ? currentColors.error : currentColors.border }]}>
                <Phone size={20} color={currentColors.textSecondary} />
                <TextInput
                  style={[styles.input, { color: currentColors.text }]}
                  placeholder="Numéro de téléphone"
                  placeholderTextColor={currentColors.textSecondary}
                  value={formData.phone}
                  onChangeText={(value) => updateFormData('phone', value)}
                  keyboardType="phone-pad"
                  autoComplete="tel"
                />
              </View>
              {errors.phone && (
                <Text style={[styles.errorText, { color: currentColors.error }]}>
                  {errors.phone}
                </Text>
              )}
            </View>

            <View style={styles.inputContainer}>
              <View style={[styles.inputWrapper, { borderColor: errors.address ? currentColors.error : currentColors.border }]}>
                <MapPin size={20} color={currentColors.textSecondary} />
                <TextInput
                  style={[styles.input, { color: currentColors.text }]}
                  placeholder="Adresse complète"
                  placeholderTextColor={currentColors.textSecondary}
                  value={formData.address}
                  onChangeText={(value) => updateFormData('address', value)}
                  autoComplete="street-address"
                  multiline
                />
              </View>
              {errors.address && (
                <Text style={[styles.errorText, { color: currentColors.error }]}>
                  {errors.address}
                </Text>
              )}
            </View>

            <View style={styles.roleSection}>
              <Text style={[styles.roleTitle, { color: currentColors.text }]}>
                Votre profil
              </Text>
              <View style={styles.roleOptions}>
                {roles.map((role) => {
                  const isSelected = formData.role === role.id;
                  const IconComponent = role.icon;
                  
                  return (
                    <TouchableOpacity
                      key={role.id}
                      style={[
                        styles.roleOption,
                        {
                          backgroundColor: isSelected ? currentColors.primary + '20' : currentColors.card,
                          borderColor: isSelected ? currentColors.primary : currentColors.border,
                        }
                      ]}
                      onPress={() => updateFormData('role', role.id)}
                    >
                      <IconComponent 
                        size={20} 
                        color={isSelected ? currentColors.primary : currentColors.textSecondary} 
                      />
                      <Text style={[
                        styles.roleOptionText,
                        { 
                          color: isSelected ? currentColors.primary : currentColors.text,
                          fontFamily: isSelected ? 'Inter-SemiBold' : 'Inter-Regular',
                        }
                      ]}>
                        {role.title}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>

            <TouchableOpacity
              style={[styles.registerButton, { backgroundColor: currentColors.primary }]}
              onPress={handleRegister}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                <Text style={styles.registerButtonText}>Créer mon compte</Text>
              )}
            </TouchableOpacity>

            <View style={styles.loginContainer}>
              <Text style={[styles.loginText, { color: currentColors.textSecondary }]}>
                Déjà un compte ?{' '}
              </Text>
              <Link href="/(auth)/login" asChild>
                <TouchableOpacity>
                  <Text style={[styles.loginLink, { color: currentColors.primary }]}>
                    Se connecter
                  </Text>
                </TouchableOpacity>
              </Link>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 24,
    paddingVertical: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
  },
  form: {
    gap: 20,
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  inputContainer: {
    gap: 8,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    gap: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
  },
  errorText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    marginLeft: 4,
  },
  roleSection: {
    gap: 12,
  },
  roleTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  roleOptions: {
    gap: 8,
  },
  roleOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    gap: 12,
  },
  roleOptionText: {
    fontSize: 16,
  },
  registerButton: {
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  registerButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  loginContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 24,
  },
  loginText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  loginLink: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
});