import React, { createContext, useContext, ReactNode } from 'react';
import { StripeProvider } from '@stripe/stripe-react-native';
import { Platform } from 'react-native';

interface StripeContextType {
  // Add any additional Stripe-related methods here
}

const StripeContext = createContext<StripeContextType | undefined>(undefined);

interface StripeProviderWrapperProps {
  children: ReactNode;
}

export function StripeProviderWrapper({ children }: StripeProviderWrapperProps) {
  const publishableKey = process.env.EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY;

  if (!publishableKey) {
    console.error('Stripe publishable key is missing. Please add EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY to your .env file');
    return <>{children}</>;
  }

  // For web platform, we'll handle Stripe differently
  if (Platform.OS === 'web') {
    return (
      <StripeContext.Provider value={{}}>
        {children}
      </StripeContext.Provider>
    );
  }

  return (
    <StripeProvider
      publishableKey={publishableKey}
      merchantIdentifier="merchant.com.montoit.plus"
    >
      <StripeContext.Provider value={{}}>
        {children}
      </StripeContext.Provider>
    </StripeProvider>
  );
}

export function useStripe() {
  const context = useContext(StripeContext);
  if (context === undefined) {
    throw new Error('useStripe must be used within a StripeProviderWrapper');
  }
  return context;
}