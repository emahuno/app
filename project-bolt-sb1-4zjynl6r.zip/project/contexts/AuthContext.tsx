import React, { createContext, useContext, useState, useEffect } from 'react';
import { router } from 'expo-router';

export type UserRole = 'tenant' | 'landlord' | 'owner';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  address: string;
  role: UserRole;
  hasSubscription?: boolean;
  stripeCustomerId?: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: RegisterData) => Promise<void>;
  logout: () => void;
  updateProfile: (data: Partial<User>) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
}

interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone: string;
  address: string;
  role: UserRole;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simuler la vérification du token au démarrage
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  }, []);

  const createStripeCustomer = async (email: string, name: string) => {
    try {
      const response = await fetch('/customer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          name,
        }),
      });

      const data = await response.json();
      return data.customerId;
    } catch (error) {
      console.error('Erreur création client Stripe:', error);
      return null;
    }
  };

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // Simulation d'une connexion
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Déterminer le rôle basé sur l'email pour la démo
      let role: UserRole = 'tenant';
      let firstName = 'Marie';
      let lastName = 'Dubois';
      
      if (email.includes('landlord') || email.includes('proprietaire')) {
        role = 'landlord';
        firstName = 'Jean';
        lastName = 'Dupont';
      } else if (email.includes('owner') || email.includes('proprio')) {
        role = 'owner';
        firstName = 'Pierre';
        lastName = 'Martin';
      }

      // Créer un client Stripe
      const stripeCustomerId = await createStripeCustomer(email, `${firstName} ${lastName}`);
      
      const mockUser: User = {
        id: '1',
        email,
        firstName,
        lastName,
        phone: '06 12 34 56 78',
        address: role === 'landlord' ? '45 avenue Victor Hugo, Lyon 3e' : '12 rue de la République, Paris 11e',
        role,
        stripeCustomerId,
      };
      
      setUser(mockUser);
      router.replace('/(tabs)');
    } catch (error) {
      throw new Error('Email ou mot de passe incorrect');
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: RegisterData) => {
    setIsLoading(true);
    try {
      // Simulation d'une inscription
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Créer un client Stripe
      const stripeCustomerId = await createStripeCustomer(
        userData.email, 
        `${userData.firstName} ${userData.lastName}`
      );
      
      const newUser: User = {
        id: Date.now().toString(),
        email: userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        phone: userData.phone,
        address: userData.address,
        role: userData.role,
        stripeCustomerId,
      };
      
      setUser(newUser);
      router.replace('/(tabs)');
    } catch (error) {
      throw new Error('Erreur lors de l\'inscription');
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    router.replace('/(auth)/login');
  };

  const updateProfile = async (data: Partial<User>) => {
    if (!user) return;
    
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      setUser({ ...user, ...data });
    } finally {
      setIsLoading(false);
    }
  };

  const resetPassword = async (email: string) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    // Simulation d'envoi d'email
  };

  return (
    <AuthContext.Provider value={{
      user,
      isLoading,
      login,
      register,
      logout,
      updateProfile,
      resetPassword,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}